import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import 'tokens.dart';

/// Acme's focus ring: contrast-fitted focus8, 2px wide, with a 2px gap.
/// Tokens resolve at the control, so nested themes and overrides work.
/// The outline takes no layout space and never replaces the control's border.
RemixBoxEffectsMix acmeFocusOutline() => RemixBoxEffectsMix(
  outline: BorderSideMix(
    color: AcmeTokens.focus8(),
    width: AcmeTokens.focusRingWidth(),
  ),
  outlineOffset: AcmeTokens.focusRingOffset(),
);

/// Keeps compact visual sizes while giving controls a 40px interaction area.
/// This wraps the painted child inside Naked UI's existing gesture target.
WidgetModifierConfig acmeTouchTarget() =>
    WidgetModifierConfig.modifier(const _AcmeTouchTargetMix());

final class _AcmeTouchTargetMix extends ModifierMix<_AcmeTouchTarget> {
  const _AcmeTouchTargetMix();

  @override
  _AcmeTouchTarget resolve(BuildContext context) =>
      _AcmeTouchTarget(AcmeTokens.touchTargetMin.resolve(context));

  @override
  _AcmeTouchTargetMix merge(_AcmeTouchTargetMix? other) => other ?? this;

  @override
  List<Object?> get props => const [];
}

final class _AcmeTouchTarget extends WidgetModifier<_AcmeTouchTarget> {
  const _AcmeTouchTarget(this.minimum);
  final double minimum;

  @override
  Widget build(Widget child) => ConstrainedBox(
    constraints: BoxConstraints(minWidth: minimum, minHeight: minimum),
    child: Center(widthFactor: 1, heightFactor: 1, child: child),
  );

  @override
  _AcmeTouchTarget copyWith({double? minimum}) =>
      _AcmeTouchTarget(minimum ?? this.minimum);

  @override
  _AcmeTouchTarget lerp(_AcmeTouchTarget? other, double t) =>
      _AcmeTouchTarget(minimum + ((other?.minimum ?? minimum) - minimum) * t);

  @override
  List<Object?> get props => [minimum];
}

/// The same outline for surfaces without a Remix effects slot.
/// [inset] measures from content inside an edge-to-edge clipped surface.
WidgetModifierConfig acmeFocusRingModifier({
  Radius? radius,
  bool visible = true,
  double inset = 0,
}) => WidgetModifierConfig.modifier(_AcmeFocusRingMix(radius, visible, inset));

extension AcmeFocusRingFlexBox on FlexBoxStyler {
  FlexBoxStyler acmeFocusRing({Radius? radius}) =>
      wrap(acmeFocusRingModifier(radius: radius));
}

extension AcmeFocusRingBox on BoxStyler {
  BoxStyler acmeFocusRing({Radius? radius, double inset = 0}) =>
      wrap(acmeFocusRingModifier(radius: radius, inset: inset));
}

final class _AcmeFocusRingMix extends ModifierMix<_AcmeFocusRingModifier> {
  const _AcmeFocusRingMix(this.radius, this.visible, this.inset);
  final Radius? radius;
  final bool visible;
  final double inset;

  @override
  _AcmeFocusRingModifier resolve(BuildContext context) {
    final outline = acmeFocusOutline().resolve(context);
    return _AcmeFocusRingModifier(
      color: visible ? outline.outline.color : const Color(0x00000000),
      width: outline.outline.width,
      offset: outline.outlineOffset,
      inset: MixOps.resolve(context, Prop.value(inset)) ?? 0,
      radius:
          MixOps.resolve(context, Prop.maybe(radius)) ??
          AcmeTokens.radius2.resolve(context),
    );
  }

  @override
  _AcmeFocusRingMix merge(_AcmeFocusRingMix? other) => other ?? this;
  @override
  List<Object?> get props => [radius, visible, inset];
}

final class _AcmeFocusRingModifier
    extends WidgetModifier<_AcmeFocusRingModifier> {
  const _AcmeFocusRingModifier({
    required this.color,
    required this.width,
    required this.offset,
    required this.radius,
    required this.inset,
  });
  final Color color;
  final double width;
  final double offset;
  final Radius radius;
  final double inset;

  @override
  _AcmeFocusRingModifier copyWith({
    Color? color,
    double? width,
    double? offset,
    Radius? radius,
    double? inset,
  }) => _AcmeFocusRingModifier(
    color: color ?? this.color,
    width: width ?? this.width,
    offset: offset ?? this.offset,
    radius: radius ?? this.radius,
    inset: inset ?? this.inset,
  );
  @override
  _AcmeFocusRingModifier lerp(_AcmeFocusRingModifier? other, double t) =>
      other == null
      ? this
      : _AcmeFocusRingModifier(
          color: Color.lerp(color, other.color, t)!,
          width: width + (other.width - width) * t,
          offset: offset + (other.offset - offset) * t,
          radius: Radius.lerp(radius, other.radius, t)!,
          inset: inset + (other.inset - inset) * t,
        );
  @override
  Widget build(Widget child) => CustomPaint(
    foregroundPainter: _AcmeFocusPainter(color, width, offset, radius, inset),
    child: child,
  );
  @override
  List<Object?> get props => [color, width, offset, radius, inset];
}

class _AcmeFocusPainter extends CustomPainter {
  const _AcmeFocusPainter(
    this.color,
    this.width,
    this.offset,
    this.radius,
    this.inset,
  );
  final Color color;
  final double width;
  final double offset;
  final Radius radius;
  final double inset;

  @override
  void paint(Canvas canvas, Size size) {
    if (color.a == 0 || width == 0) return;
    final box = RRect.fromRectAndRadius(
      (Offset.zero & size).deflate(inset),
      radius,
    );
    canvas.drawDRRect(
      box.inflate(offset + width),
      box.inflate(offset),
      Paint()..color = color,
    );
  }

  @override
  bool shouldRepaint(_AcmeFocusPainter old) =>
      color != old.color ||
      width != old.width ||
      offset != old.offset ||
      radius != old.radius ||
      inset != old.inset;
}

/// A crisp inset frame, not an elevation shadow. No blur or offset is used.
RemixBoxEffectLayerMix acmeInsetSurface({required List<Color> strokes}) =>
    RemixBoxEffectLayerMix(
      shadows: [
        for (final stroke in strokes)
          RemixBoxShadowMix(
            kind: .inset,
            color: stroke,
            spreadRadius: AcmeTokens.borderWidth1(),
          ),
      ],
    );
