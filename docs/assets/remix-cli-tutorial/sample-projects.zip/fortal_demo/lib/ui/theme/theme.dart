// The theme layer's barrel: every Fortal component imports it, and the
// library entrypoint re-exports it.

export 'computed.dart'
    show
        AcmeThemeColors,
        computeAccentThumbRing,
        computeChartSeries,
        computeContrastRatio,
        resolveAcmeTokens;
export 'control_styles.dart';
export 'surface_frame.dart';
export 'theme_data.dart' hide buildAcmeScopeTokens;
export 'theme_scope.dart';
export 'tokens.dart';

// Import fortal_colors.dart for the accent palettes, whose bare names stay
// out of this barrel, and palette.dart for their types. The prefixed error
// palette is exported so applications can scope destructive content without
// a deep import.
export 'fortal_colors.dart' show acmeError;
