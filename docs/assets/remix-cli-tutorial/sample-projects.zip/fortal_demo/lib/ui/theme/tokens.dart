import 'package:remix/remix.dart';

import 'theme_scope.dart' show AcmeTheme;

/// Design tokens for the Acme UI system and its paired color themes.
///
/// Provides color scales (12-step accent/gray), spacing (9-step), radius (6-step),
/// shadows (6-level), typography (9-size), and functional colors.
///
/// Example:
/// ```dart
/// ButtonStyler().color(AcmeTokens.accentSolid())
/// ```
///
/// Must be used within [AcmeTheme] to resolve actual values.
class AcmeTokens {
  static const activityMaxHeight = DoubleToken('acme.activity.max-height');
  static const planMaxHeight = DoubleToken('acme.plan.max-height');
  static const messageAvatarSize = DoubleToken('acme.message.avatar-size');
  static const messageContentMaxWidth = DoubleToken(
    'acme.message.content-max-width',
  );
  static const messageCollapsedHeight = DoubleToken(
    'acme.message.collapsed-height',
  );
  static const composerFieldMinHeight = DoubleToken(
    'acme.composer-field-min-height',
  );
  static const touchTargetMin = DoubleToken('acme.touch-target-min');
  static const popoverMaxWidth = DoubleToken('acme.popover-max-width');
  static const dialogMaxWidth = DoubleToken('acme.dialog-max-width');
  static const toastMaxWidth = DoubleToken('acme.toast-max-width');
  static const sidebarDestinationMinHeight = DoubleToken(
    'acme.sidebar.destination-min-height',
  );

  /// Sort icons retain their optical sizes where the spacing scale has no step.
  static const dataTableSortIconSize1 = DoubleToken(
    'acme.data-table.sort-icon-size.1',
  );
  static const dataTableSortIconSize3 = DoubleToken(
    'acme.data-table.sort-icon-size.3',
  );

  /// Page background color selected for the active brightness.
  static const colorBackground = ColorToken('acme.color.background');

  /// Neutral surface color for input fields and controls.
  static const colorSurface = ColorToken('acme.color.surface');

  /// Selected SegmentedControl surface for the active brightness.
  static const segmentedControlIndicatorBackground = ColorToken(
    'acme.segmented-control.indicator-background',
  );

  /// Solid panel background selected for the active brightness.
  static const colorPanelSolid = ColorToken('acme.color.panel.solid');

  /// Translucent panel background with alpha transparency.
  static const colorPanelTranslucent = ColorToken(
    'acme.color.panel.translucent',
  );

  /// Panel background selected by [AcmePanelBackground].
  static const colorPanel = ColorToken('acme.color.panel');

  /// Backdrop blur applied to translucent floating panels.
  static const panelBlur = DoubleToken('acme.panel.blur');

  /// Dark overlay for modals and dialogs.
  static const colorOverlay = ColorToken('acme.color.overlay');

  /// Subtle accent surface for soft button variants and chips.
  static const accentSurface = ColorToken('acme.accent.surface');

  /// Mark fill of selected checkboxes, radios and tab indicators; white or
  /// [accentIndicatorContrast] marks keep 3:1 on it.
  static const accentIndicator = ColorToken('acme.accent.indicator');

  /// Selected switch track and slider and progress range, under a light
  /// thumb outlined by [accentThumbRing].
  static const accentTrack = ColorToken('acme.accent.track');

  /// Hovered or pressed selected mark/track fill, paired with its mark ink.
  static const accentMarkHover = ColorToken('acme.accent.mark-hover');

  /// Mode-aware overlay used by high-contrast slider ranges.
  static const sliderHighContrastOverlay = ColorToken(
    'acme.slider.high-contrast-overlay',
  );

  /// Label colour on [accentSolid] and [accentSolidHover] (4.5:1 or more).
  static const accentContrast = ColorToken('acme.accent.contrast');

  /// Labelled solid fill of buttons, icon buttons, solid badges, avatars,
  /// code and highlighted menu and select items. It can be deeper than
  /// raw [accent9]. Small-control marks use [accentIndicator].
  static const accentSolid = ColorToken('acme.accent.solid');

  /// Hovered [accentSolid]; pressed fills are derived from it.
  static const accentSolidHover = ColorToken('acme.accent.solid-hover');

  /// Check and radio-dot ink on [accentIndicator] (3:1 or more): white where
  /// it fits, otherwise a dark ink.
  static const accentIndicatorContrast = ColorToken(
    'acme.accent.indicator-contrast',
  );

  /// Outline of a white switch or slider thumb: the track colour where white
  /// stands out on the track, [controlBorder] where the track is too light
  /// against the page, and a dark ink on bright tracks.
  static const accentThumbRing = ColorToken('acme.accent.thumb-ring');

  /// Neutral boundary of active empty controls (unchecked checkbox and radio,
  /// off switch, surface text input), at least 3:1 against page and panel.
  static const controlBorder = ColorToken('acme.control.border');

  /// Source accent step 8 fitted to the focus ring's 3:1 contrast contract.
  static const focus8 = ColorToken('acme.focus.8');

  /// Translucent text-selection color (accent alpha step 5).
  static const focusA5 = ColorToken('acme.focus.a5');

  /// Translucent focus ring color with alpha transparency.
  static const focusA8 = ColorToken('acme.focus.a8');

  /// Mode-aware red roles used by documented validation extensions.
  static const error3 = ColorToken('acme.error.3');
  static const error7 = ColorToken('acme.error.7');
  static const error8 = ColorToken('acme.error.8');
  static const error9 = ColorToken('acme.error.9');
  static const error11 = ColorToken('acme.error.11');
  static const error12 = ColorToken('acme.error.12');
  static const errorA7 = ColorToken('acme.error.a7');

  /// Accent step 1 - App background, most subtle.
  static const accent1 = ColorToken('acme.accent.1');

  /// Accent step 2 - Subtle background.
  static const accent2 = ColorToken('acme.accent.2');

  /// Accent step 3 - Component background at rest.
  static const accent3 = ColorToken('acme.accent.3');

  /// Accent step 4 - Component background on hover.
  static const accent4 = ColorToken('acme.accent.4');

  /// Accent step 5 - Component background when active/pressed.
  static const accent5 = ColorToken('acme.accent.5');

  /// Accent step 6 - Subtle borders and separators.
  static const accent6 = ColorToken('acme.accent.6');

  /// Accent step 7 - Component borders at rest.
  static const accent7 = ColorToken('acme.accent.7');

  /// Accent step 8 - Component borders on hover and focus.
  static const accent8 = ColorToken('acme.accent.8');

  /// Accent step 9 - The most chromatic step: the mark fill behind
  /// [accentIndicator] and [accentTrack], and accent dots and icons. Labelled
  /// fills use [accentSolid].
  static const accent9 = ColorToken('acme.accent.9');

  /// Accent step 10 - Pressed or hovered mark fill. Labelled fills use
  /// [accentSolidHover].
  static const accent10 = ColorToken('acme.accent.10');

  /// Accent step 11 - Low contrast text.
  static const accent11 = ColorToken('acme.accent.11');

  /// Normal content fitted to the theme's soft and neutral surfaces.
  static const accentContent = ColorToken('acme.accent.content');

  /// Alpha content retained or fitted to the same contrast contract.
  static const accentContentAlpha = ColorToken('acme.accent.content-alpha');

  /// Accent step 12 - High contrast text.
  static const accent12 = ColorToken('acme.accent.12');

  /// Gray step 1 - Page background.
  static const gray1 = ColorToken('acme.gray.1');

  /// Gray step 2 - Panel and card backgrounds.
  static const gray2 = ColorToken('acme.gray.2');

  /// Gray step 3 - Input backgrounds and pressed states.
  static const gray3 = ColorToken('acme.gray.3');

  /// Gray step 4 - Input backgrounds on hover.
  static const gray4 = ColorToken('acme.gray.4');

  /// Gray step 5 - Active states and disabled backgrounds.
  static const gray5 = ColorToken('acme.gray.5');

  /// Gray step 6 - Subtle borders and dividers.
  static const gray6 = ColorToken('acme.gray.6');

  /// Gray step 7 - Standard borders and outlines.
  static const gray7 = ColorToken('acme.gray.7');

  /// Gray step 8 - Borders on hover and focus.
  static const gray8 = ColorToken('acme.gray.8');

  /// Gray step 9 - Solid neutral backgrounds.
  static const gray9 = ColorToken('acme.gray.9');

  /// Gray step 10 - Solid neutral backgrounds on hover.
  static const gray10 = ColorToken('acme.gray.10');

  /// Gray step 11 - Low contrast text and secondary content.
  static const gray11 = ColorToken('acme.gray.11');

  /// Gray step 12 - High contrast text and primary content.
  static const gray12 = ColorToken('acme.gray.12');

  /// Neutral surface baseline for the selected gray scale (matches JSON surface)
  static const graySurface = ColorToken('acme.gray.surface');

  /// Neutral indicator color (typically gray step 9)
  static const grayIndicator = ColorToken('acme.gray.indicator');

  /// Neutral track color (typically gray step 9)
  static const grayTrack = ColorToken('acme.gray.track');

  /// Contrast color for content over neutral solid backgrounds (white)
  static const grayContrast = ColorToken('acme.gray.contrast');

  // Accent alpha steps a1..a12
  static const accentA1 = ColorToken('acme.accent.a1');
  static const accentA2 = ColorToken('acme.accent.a2');
  static const accentA3 = ColorToken('acme.accent.a3');
  static const accentA4 = ColorToken('acme.accent.a4');
  static const accentA5 = ColorToken('acme.accent.a5');
  static const accentA6 = ColorToken('acme.accent.a6');
  static const accentA7 = ColorToken('acme.accent.a7');
  static const accentA8 = ColorToken('acme.accent.a8');
  static const accentA9 = ColorToken('acme.accent.a9');
  static const accentA10 = ColorToken('acme.accent.a10');
  static const accentA11 = ColorToken('acme.accent.a11');
  static const accentA12 = ColorToken('acme.accent.a12');

  // Gray alpha steps a1..a12
  static const grayA1 = ColorToken('acme.gray.a1');
  static const grayA2 = ColorToken('acme.gray.a2');
  static const grayA3 = ColorToken('acme.gray.a3');
  static const grayA4 = ColorToken('acme.gray.a4');
  static const grayA5 = ColorToken('acme.gray.a5');
  static const grayA6 = ColorToken('acme.gray.a6');
  static const grayA7 = ColorToken('acme.gray.a7');
  static const grayA8 = ColorToken('acme.gray.a8');
  static const grayA9 = ColorToken('acme.gray.a9');
  static const grayA10 = ColorToken('acme.gray.a10');
  static const grayA11 = ColorToken('acme.gray.a11');
  static const grayA12 = ColorToken('acme.gray.a12');

  /// Black alpha steps used in layered shadows.
  static const blackA1 = ColorToken('acme.black.a1');
  static const blackA2 = ColorToken('acme.black.a2');
  static const blackA3 = ColorToken('acme.black.a3');
  static const blackA4 = ColorToken('acme.black.a4');
  static const blackA5 = ColorToken('acme.black.a5');
  static const blackA6 = ColorToken('acme.black.a6');
  static const blackA7 = ColorToken('acme.black.a7');
  static const blackA8 = ColorToken('acme.black.a8');
  static const blackA9 = ColorToken('acme.black.a9');
  static const blackA10 = ColorToken('acme.black.a10');
  static const blackA11 = ColorToken('acme.black.a11');
  static const blackA12 = ColorToken('acme.black.a12');

  /// White alpha steps for transparent decoration and overlays.
  static const whiteA1 = ColorToken('acme.white.a1');
  static const whiteA2 = ColorToken('acme.white.a2');
  static const whiteA3 = ColorToken('acme.white.a3');
  static const whiteA4 = ColorToken('acme.white.a4');
  static const whiteA5 = ColorToken('acme.white.a5');
  static const whiteA6 = ColorToken('acme.white.a6');
  static const whiteA7 = ColorToken('acme.white.a7');
  static const whiteA8 = ColorToken('acme.white.a8');
  static const whiteA9 = ColorToken('acme.white.a9');
  static const whiteA10 = ColorToken('acme.white.a10');
  static const whiteA11 = ColorToken('acme.white.a11');
  static const whiteA12 = ColorToken('acme.white.a12');

  /// Mode-aware mixed shadow stroke.
  static const shadowStroke = ColorToken('acme.shadow.stroke');

  static const grayStroke3 = ColorToken('acme.gray.stroke.3');
  static const grayStroke4 = ColorToken('acme.gray.stroke.4');
  static const grayStroke5 = ColorToken('acme.gray.stroke.5');
  static const grayStroke6 = ColorToken('acme.gray.stroke.6');
  static const grayStroke7 = ColorToken('acme.gray.stroke.7');

  /// Space step 1 - 4px.
  static const space1 = SpaceToken('acme.space.1');

  /// Space step 2 - 8px.
  static const space2 = SpaceToken('acme.space.2');

  /// Space step 3 - 12px.
  static const space3 = SpaceToken('acme.space.3');

  /// Space step 4 - 16px.
  static const space4 = SpaceToken('acme.space.4');

  /// Space step 5 - 24px.
  static const space5 = SpaceToken('acme.space.5');

  /// Space step 6 - 32px.
  static const space6 = SpaceToken('acme.space.6');

  /// Space step 7 - 40px.
  static const space7 = SpaceToken('acme.space.7');

  /// Space step 8 - 48px.
  static const space8 = SpaceToken('acme.space.8');

  /// Space step 9 - 64px.
  static const space9 = SpaceToken('acme.space.9');

  /// Spinner size 3 - 20px at 100% scaling.
  static const spinnerSize3 = DoubleToken('acme.spinner.size.3');

  /// Avatar sizes expressed as scaled pixels rather than spacing steps.
  static const avatarSize6 = DoubleToken('acme.avatar.size.6');
  static const avatarSize7 = DoubleToken('acme.avatar.size.7');
  static const avatarSize8 = DoubleToken('acme.avatar.size.8');
  static const avatarSize9 = DoubleToken('acme.avatar.size.9');

  static const avatarIconSize3 = DoubleToken('acme.avatar.icon-size.3');
  static const avatarIconSize9 = DoubleToken('acme.avatar.icon-size.9');

  static const badgePaddingY1 = DoubleToken('acme.badge.padding-y.1');

  /// Checkbox dimensions expressed as scaled pixels by Acme.
  static const checkboxSize1 = DoubleToken('acme.checkbox.size.1');
  static const checkboxSize3 = DoubleToken('acme.checkbox.size.3');
  static const checkboxIndicatorSize1 = DoubleToken(
    'acme.checkbox.indicator-size.1',
  );
  static const checkboxIndicatorSize2 = DoubleToken(
    'acme.checkbox.indicator-size.2',
  );

  /// Radio indicators are 40% of their control size in Acme.
  ///
  /// These values need dedicated tokens because arithmetic on an unresolved
  /// token reference would destroy its identity before Mix can resolve it.
  static const radioIndicatorSize1 = DoubleToken('acme.radio.indicator-size.1');
  static const radioIndicatorSize2 = DoubleToken('acme.radio.indicator-size.2');

  /// Checkbox radii derived from fractional radius-step expressions.
  static const checkboxRadius1 = RadiusToken('acme.checkbox.radius.1');
  static const checkboxRadius3 = RadiusToken('acme.checkbox.radius.3');

  /// Switch geometry that cannot be derived from unresolved token references.
  static const switchHeight2 = DoubleToken('acme.switch.height.2');
  static const switchWidth1 = DoubleToken('acme.switch.width.1');
  static const switchWidth2 = DoubleToken('acme.switch.width.2');
  static const switchWidth3 = DoubleToken('acme.switch.width.3');
  static const switchThumbSize1 = DoubleToken('acme.switch.thumb-size.1');
  static const switchThumbSize2 = DoubleToken('acme.switch.thumb-size.2');
  static const switchThumbSize3 = DoubleToken('acme.switch.thumb-size.3');

  static const progressHeight2 = DoubleToken('acme.progress.height.2');
  static const progressRadius1 = RadiusToken('acme.progress.radius.1');
  static const progressRadius2 = RadiusToken('acme.progress.radius.2');
  static const progressRadius3 = RadiusToken('acme.progress.radius.3');

  static const sliderTrackSize1 = DoubleToken('acme.slider.track-size.1');
  static const sliderTrackSize3 = DoubleToken('acme.slider.track-size.3');
  static const sliderThumbSize1 = DoubleToken('acme.slider.thumb-size.1');
  static const sliderThumbSize3 = DoubleToken('acme.slider.thumb-size.3');
  static const sliderTrackRadius1 = RadiusToken('acme.slider.track-radius.1');
  static const sliderTrackRadius2 = RadiusToken('acme.slider.track-radius.2');
  static const sliderTrackRadius3 = RadiusToken('acme.slider.track-radius.3');

  /// TextArea metrics that cannot be expressed by existing spacing tokens.
  static const textAreaMinHeight3 = DoubleToken('acme.text-area.min-height.3');

  /// DataList metrics that cannot be expressed by existing spacing tokens.
  static const dataListRowGap3 = DoubleToken('acme.data-list.row-gap.3');
  static const dataListLabelMinWidth = DoubleToken(
    'acme.data-list.label-min-width',
  );

  /// Exact uppercase fallback typography for each Avatar size.
  static const avatarFallback1One = TextStyleToken(
    'acme.avatar.fallback.1.one',
  );
  static const avatarFallback1Two = TextStyleToken(
    'acme.avatar.fallback.1.two',
  );
  static const avatarFallback2One = TextStyleToken(
    'acme.avatar.fallback.2.one',
  );
  static const avatarFallback2Two = TextStyleToken(
    'acme.avatar.fallback.2.two',
  );
  static const avatarFallback3One = TextStyleToken(
    'acme.avatar.fallback.3.one',
  );
  static const avatarFallback3Two = TextStyleToken(
    'acme.avatar.fallback.3.two',
  );
  static const avatarFallback4One = TextStyleToken(
    'acme.avatar.fallback.4.one',
  );
  static const avatarFallback4Two = TextStyleToken(
    'acme.avatar.fallback.4.two',
  );
  static const avatarFallback5 = TextStyleToken('acme.avatar.fallback.5');
  static const avatarFallback6 = TextStyleToken('acme.avatar.fallback.6');
  static const avatarFallback7 = TextStyleToken('acme.avatar.fallback.7');
  static const avatarFallback8 = TextStyleToken('acme.avatar.fallback.8');
  static const avatarFallback9 = TextStyleToken('acme.avatar.fallback.9');

  /// Tabs size 1 inner vertical padding - 2px at 100% scaling.
  static const tabInnerPaddingY1 = DoubleToken('acme.tabs.inner-padding-y.1');

  /// Tabs size 1 active tracking - -0.12px at 100% scaling.
  static const tabActiveLetterSpacing1 = DoubleToken(
    'acme.tabs.active-letter-spacing.1',
  );

  /// Tabs size 2 active tracking - -0.14px at 100% scaling.
  static const tabActiveLetterSpacing2 = DoubleToken(
    'acme.tabs.active-letter-spacing.2',
  );

  /// Table surface border - `color-mix(in oklab, gray-a5, gray-6)`.
  ///
  /// The existing `grayStroke*` tokens blend an alpha step with the *same*
  /// numbered solid step at 25%; Table blends step 5 with step 6 at 50%.
  static const dataTableBorder = ColorToken('acme.data-table.border');

  /// Select size-1 indicator column width (20px at 100% scaling).
  static const selectIndicatorWidth1 = DoubleToken(
    'acme.select.indicator-width.1',
  );

  /// Select size-2/3 check size (10px at 100% scaling).
  static const selectIndicatorSize2 = DoubleToken(
    'acme.select.indicator-size.2',
  );

  /// Negative margins that cancel Select ghost-trigger padding.
  static const selectGhostMarginX12 = DoubleToken(
    'acme.select.ghost-margin-x.1-2',
  );
  static const selectGhostMarginY12 = DoubleToken(
    'acme.select.ghost-margin-y.1-2',
  );
  static const selectGhostMarginX3 = DoubleToken(
    'acme.select.ghost-margin-x.3',
  );
  static const selectGhostMarginY3 = DoubleToken(
    'acme.select.ghost-margin-y.3',
  );

  /// Radius step 1 - 3px.
  static const radius1 = RadiusToken('acme.radius.1');

  /// Radius step 2 - 4px.
  static const radius2 = RadiusToken('acme.radius.2');

  /// Radius step 3 - 6px.
  static const radius3 = RadiusToken('acme.radius.3');

  /// Radius step 4 - 8px.
  static const radius4 = RadiusToken('acme.radius.4');

  /// Radius step 5 - 12px.
  static const radius5 = RadiusToken('acme.radius.5');

  /// Radius step 6 - 16px.
  static const radius6 = RadiusToken('acme.radius.6');

  /// Theme-level full radius, enabled only by [AcmeRadius.full].
  static const radiusFull = RadiusToken('acme.radius.full');

  /// Radius used by control thumbs.
  static const radiusThumb = RadiusToken('acme.radius.thumb');

  /// Fixed circle radius for shapes that stay circular across theme presets.
  static const radiusCircle = RadiusToken('acme.radius.circle');

  /// Radius step 1 promoted to a pill when the theme radius is full.
  static const radius1OrFull = RadiusToken('acme.radius.1-or-full');

  /// Radius step 2 promoted to a pill when the theme radius is full.
  static const radius2OrFull = RadiusToken('acme.radius.2-or-full');

  /// Radius step 3 promoted to a pill when the theme radius is full.
  static const radius3OrFull = RadiusToken('acme.radius.3-or-full');

  /// Radius step 4 promoted to a pill when the theme radius is full.
  static const radius4OrFull = RadiusToken('acme.radius.4-or-full');

  /// Radius step 5 promoted to a pill when the theme radius is full.
  static const radius5OrFull = RadiusToken('acme.radius.5-or-full');

  /// Radius step 6 promoted to a pill when the theme radius is full.
  static const radius6OrFull = RadiusToken('acme.radius.6-or-full');

  /// Radius step 1 promoted to the control-thumb radius when larger.
  static const radius1OrThumb = RadiusToken('acme.radius.1-or-thumb');

  /// Radius step 2 promoted to the control-thumb radius when larger.
  static const radius2OrThumb = RadiusToken('acme.radius.2-or-thumb');

  /// Shadow level 1 - Subtle elevation.
  static const shadow1 = BoxShadowToken('acme.shadow.1');

  /// Exact layered shadow level 1, including inset layers.
  static const shadow1Layers = RemixBoxShadowListToken('acme.shadow.1.layers');

  /// Shadow level 2 - Low elevation.
  static const shadow2 = BoxShadowToken('acme.shadow.2');

  /// Shadow level 3 - Medium elevation.
  static const shadow3 = BoxShadowToken('acme.shadow.3');

  /// Shadow level 4 - High elevation.
  static const shadow4 = BoxShadowToken('acme.shadow.4');

  /// Shadow level 5 - Very high elevation.
  static const shadow5 = BoxShadowToken('acme.shadow.5');

  /// Shadow level 6 - Maximum elevation.
  static const shadow6 = BoxShadowToken('acme.shadow.6');

  static const baseButtonGhostMarginX12 = DoubleToken(
    'acme.base-button.ghost.margin-x.1-2',
  );
  static const baseButtonGhostMarginY12 = DoubleToken(
    'acme.base-button.ghost.margin-y.1-2',
  );
  static const baseButtonGhostMarginX3 = DoubleToken(
    'acme.base-button.ghost.margin-x.3',
  );
  static const baseButtonGhostMarginY3 = DoubleToken(
    'acme.base-button.ghost.margin-y.3',
  );
  static const baseButtonGhostMarginX4 = DoubleToken(
    'acme.base-button.ghost.margin-x.4',
  );
  static const baseButtonGhostMarginY4 = DoubleToken(
    'acme.base-button.ghost.margin-y.4',
  );
  static const iconButtonGhostMargin1 = DoubleToken(
    'acme.icon-button.ghost.margin.1',
  );
  static const iconButtonGhostMargin2 = DoubleToken(
    'acme.icon-button.ghost.margin.2',
  );
  static const iconButtonGhostMargin3 = DoubleToken(
    'acme.icon-button.ghost.margin.3',
  );
  static const iconButtonGhostMargin4 = DoubleToken(
    'acme.icon-button.ghost.margin.4',
  );
  static const cardGhostMargin1 = DoubleToken('acme.card.ghost.margin.1');
  static const cardGhostMargin2 = DoubleToken('acme.card.ghost.margin.2');
  static const cardGhostMargin3 = DoubleToken('acme.card.ghost.margin.3');
  static const cardGhostMargin4 = DoubleToken('acme.card.ghost.margin.4');
  static const cardGhostMargin5 = DoubleToken('acme.card.ghost.margin.5');

  /// Standard border width (1px).
  static const borderWidth1 = SpaceToken('acme.border.width.1');

  /// Thick border width (2px).
  static const borderWidth2 = SpaceToken('acme.border.width.2');

  /// Focus ring border width (2px).
  static const focusRingWidth = SpaceToken('acme.focus.ring.width');

  /// Focus ring offset distance from element edge.
  static const focusRingOffset = SpaceToken('acme.focus.ring.offset');

  /// Text size 1 - 12px (Small labels and metadata).
  static const text1 = TextStyleToken('acme.text.1');

  /// Text size 2 - 14px (Standard UI text).
  static const text2 = TextStyleToken('acme.text.2');

  /// Text size 3 - 16px (Body text and primary content).
  static const text3 = TextStyleToken('acme.text.3');

  /// Text size 4 - 18px (Prominent body text).
  static const text4 = TextStyleToken('acme.text.4');

  /// Text size 5 - 20px (Small headings).
  static const text5 = TextStyleToken('acme.text.5');

  /// Text size 6 - 24px (Medium headings).
  static const text6 = TextStyleToken('acme.text.6');

  /// Text size 7 - 28px (Large headings).
  static const text7 = TextStyleToken('acme.text.7');

  /// Text size 8 - 36px (Extra large headings).
  static const text8 = TextStyleToken('acme.text.8');

  /// Text size 9 - 60px (Display text).
  static const text9 = TextStyleToken('acme.text.9');

  /// Light font weight (300).
  static const fontWeightLight = FontWeightToken('acme.font.weight.light');

  /// Regular font weight (400).
  static const fontWeightRegular = FontWeightToken('acme.font.weight.regular');

  /// Medium font weight (500).
  static const fontWeightMedium = FontWeightToken('acme.font.weight.medium');

  /// Semibold font weight (600).
  static const fontWeightSemibold = FontWeightToken(
    'acme.font.weight.semibold',
  );

  /// Bold font weight (700).
  static const fontWeightBold = FontWeightToken('acme.font.weight.bold');

  /// Fast animation duration (100ms).
  static const transitionFast = DurationToken('acme.transition.fast');

  /// Slow animation duration (300ms).
  static const transitionSlow = DurationToken('acme.transition.slow');

  static const skeletonPulseDuration = DurationToken(
    'acme.skeleton.pulse-duration',
  );
}
