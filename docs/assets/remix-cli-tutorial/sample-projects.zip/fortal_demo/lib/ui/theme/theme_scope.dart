import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import 'palette.dart';
import 'theme_data.dart';
import 'tokens.dart';

/// Establishes Acme's body text and neutral foreground at the root.
/// Nested scopes preserve the surrounding text run; mode changes recolor it.
Widget _acmeRootTextStyle({
  required Map<MixToken<Object?>, Object> tokens,
  required Widget child,
}) {
  final root = tokens[AcmeTokens.text3]! as TextStyle;
  final foreground = tokens[AcmeTokens.gray12]! as Color;

  return DefaultTextStyle(
    style: root.copyWith(
      color: foreground,
      fontWeight: tokens[AcmeTokens.fontWeightRegular]! as FontWeight,
    ),
    child: IconTheme.merge(
      data: IconThemeData(color: foreground),
      child: child,
    ),
  );
}

Widget _acmeRecolored(Color foreground, Widget child) => DefaultTextStyle.merge(
  style: TextStyle(color: foreground),
  child: IconTheme.merge(
    data: IconThemeData(color: foreground),
    child: child,
  ),
);

/// Widget that provides Acme design tokens to its subtree via [MixScope].
///
/// Place [AcmeTheme] below the application host so its text defaults apply.
/// For a routed app, wrap the navigator in the host's builder. This also keeps
/// [AcmeTokens] available to routes and dialogs.
///
/// ```dart
/// WidgetsApp(
///   color: const Color(0xFFF8FAFC),
///   pageRouteBuilder: <T>(settings, builder) => PageRouteBuilder<T>(
///     settings: settings,
///     pageBuilder: (context, animation, secondaryAnimation) => builder(context),
///   ),
///   builder: (_, child) => AcmeTheme(child: child!),
///   home: const HomePage(),
/// )
/// ```
class AcmeTheme extends StatelessWidget {
  const AcmeTheme({
    super.key,
    this.theme,
    this.darkTheme,
    this.mode,
    this.accent,
    this.accentPalette,
    this.gray,
    this.panelBackground,
    this.radius,
    this.scaling,
    this.hasBackground,
    this.orderOfModifiers,
    required this.child,
  });

  /// Base appearance. Without either theme, the preset provides both defaults.
  /// If only [theme] is supplied, it is also the dark-mode fallback.
  final AcmeThemeConfig? theme;
  final AcmeThemeConfig? darkTheme;

  /// Omitted at a root follows the system; omitted below a scope inherits it.
  final AcmeThemeMode? mode;

  final AcmeAccentColor? accent;
  final AcmeColorTheme? accentPalette;
  final AcmeGrayColor? gray;
  final AcmePanelBackground? panelBackground;
  final AcmeRadius? radius;
  final AcmeScaling? scaling;
  final bool? hasBackground;
  final List<Type>? orderOfModifiers;
  final Widget child;

  /// Returns the closest resolved Acme theme.
  static AcmeThemeData of(BuildContext context) {
    final data = maybeOf(context);
    if (data != null) return data;
    throw FlutterError.fromParts([
      ErrorSummary('No AcmeTheme found.'),
      ErrorDescription(
        '${context.widget.runtimeType} tried to read the Acme theme, but no AcmeTheme was found above it.',
      ),
      context.describeElement('The context used was'),
    ]);
  }

  /// Returns the closest resolved Acme theme, if one is available.
  static AcmeThemeData? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<_AcmeInheritedTheme>()?.data;

  @override
  Widget build(BuildContext context) {
    final view = View.maybeOf(context);
    if (MediaQuery.maybeOf(context) == null && view != null) {
      return MediaQuery.fromView(
        view: view,
        child: Builder(builder: _build),
      );
    }
    return _build(context);
  }

  Widget _build(BuildContext context) {
    final inherited = context
        .dependOnInheritedWidgetOfExactType<_AcmeInheritedTheme>();
    final parent = inherited?.data;
    final baseParent = inherited?.baseTheme ?? parent;
    final darkParent = inherited?.darkTheme ?? parent;
    AcmeThemeData resolve(
      AcmeThemeConfig? supplied,
      AcmeThemeData? ancestor,
      Brightness fallback,
    ) {
      final config = supplied ?? const AcmeThemeConfig();
      return _resolveAcmeTheme(
        AcmeThemeConfig(
          accent: accent ?? config.accent,
          accentPalette:
              accentPalette ?? (accent == null ? config.accentPalette : null),
          gray: gray ?? config.gray,
          brightness: config.brightness ?? ancestor?.brightness ?? fallback,
          panelBackground: panelBackground ?? config.panelBackground,
          radius: radius ?? config.radius,
          scaling: scaling ?? config.scaling,
          hasBackground: hasBackground ?? config.hasBackground,
        ),
        parent: ancestor,
      );
    }

    final base = resolve(theme, baseParent, Brightness.light);
    final dark = darkTheme == null && theme != null
        ? base
        : resolve(darkTheme, darkParent, Brightness.dark);
    final useDark = mode == null && inherited != null
        ? inherited.usesDarkTheme
        : switch (mode ?? AcmeThemeMode.system) {
            AcmeThemeMode.light => false,
            AcmeThemeMode.dark => true,
            AcmeThemeMode.system =>
              (MediaQuery.maybePlatformBrightnessOf(context) ??
                      Brightness.light) ==
                  Brightness.dark,
          };
    final data = useDark ? dark : base;
    final tokens = buildAcmeScopeTokens(data);
    final foreground = tokens[AcmeTokens.gray12]! as Color;
    Widget scoped = child;
    if (parent == null) {
      scoped = _acmeRootTextStyle(tokens: tokens, child: scoped);
    } else if (parent.brightness != data.brightness ||
        parent.gray != data.gray) {
      scoped = _acmeRecolored(foreground, scoped);
    }
    Widget result = MixScope(
      tokens: tokens,
      orderOfModifiers: orderOfModifiers,
      // Theme-root identity, not `hasBackground`, decides who owns the text
      // run: a scope nested for its accent or scaling must leave the current
      // run alone, while a root scope with `hasBackground: false` still
      // establishes it.
      child: scoped,
    );
    if (data.hasBackground) {
      result = ColoredBox(
        color: tokens[AcmeTokens.colorBackground]! as Color,
        child: result,
      );
    }

    return _AcmeInheritedTheme(
      data: data,
      baseTheme: base,
      darkTheme: dark,
      useDarkTheme: useDark,
      orderOfModifiers: orderOfModifiers,
      child: result,
    );
  }
}

AcmeThemeData _resolveAcmeTheme(
  AcmeThemeConfig config, {
  AcmeThemeData? parent,
}) {
  final accent = config.accent ?? parent?.accent ?? AcmeAccentColor.calcadao;

  return AcmeThemeData(
    accent: accent,
    accentPalette:
        config.accentPalette ??
        (config.accent == null ? parent?.accentPalette : null),
    gray: config.gray ?? parent?.gray ?? AcmeGrayColor.calcadao,
    brightness: config.brightness ?? parent?.brightness ?? Brightness.light,
    panelBackground:
        config.panelBackground ??
        parent?.panelBackground ??
        AcmePanelBackground.solid,
    radius: config.radius ?? parent?.radius ?? AcmeRadius.medium,
    scaling: config.scaling ?? parent?.scaling ?? AcmeScaling.percent100,
    hasBackground: config.hasBackground ?? parent == null,
  );
}

/// The inherited half of [AcmeTheme].
class _AcmeInheritedTheme extends InheritedTheme {
  const _AcmeInheritedTheme({
    required this.data,
    this.baseTheme,
    this.darkTheme,
    this.useDarkTheme,
    this.orderOfModifiers,
    required super.child,
  });

  final AcmeThemeData data;
  final AcmeThemeData? baseTheme;
  final AcmeThemeData? darkTheme;
  final bool? useDarkTheme;
  bool get usesDarkTheme => useDarkTheme ?? data.isDark;
  final List<Type>? orderOfModifiers;

  /// Rebuilds only the theme and its Mix tokens.
  ///
  /// The captured subtree's text run is *not* synthesized here.
  /// `DefaultTextStyle` is itself an [InheritedTheme], so
  /// `InheritedTheme.capture` already carries the actual nearest ambient run
  /// across to the new route; installing a new root run alongside it would
  /// overwrite that capture with a value the source context never had.
  @override
  Widget wrap(BuildContext context, Widget child) => _AcmeInheritedTheme(
    data: data,
    baseTheme: baseTheme,
    darkTheme: darkTheme,
    useDarkTheme: useDarkTheme,
    orderOfModifiers: orderOfModifiers,
    child: MixScope(
      tokens: buildAcmeScopeTokens(data),
      orderOfModifiers: orderOfModifiers,
      child: child,
    ),
  );

  @override
  bool updateShouldNotify(_AcmeInheritedTheme oldWidget) =>
      data != oldWidget.data ||
      baseTheme != oldWidget.baseTheme ||
      darkTheme != oldWidget.darkTheme ||
      useDarkTheme != oldWidget.useDarkTheme;
}
