import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

/// The Acme BaseButton size scale shared by Button and IconButton.
///
/// Deliberate: this mirrors [AcmeBaseButtonVariant]. Button and IconButton
/// each own a size enum, so the shared metrics need a common type — passing the
/// raw `size.index + 1` instead would drop every switch below to a wildcard and
/// defer an unknown size to a runtime throw.
enum AcmeBaseButtonSize { size1, size2, size3, size4 }

/// Transition into hover and press, the same 40ms ease as `AcmeCard`.
final acmeBaseButtonActiveMotion = AnimationConfig.ease(
  const Duration(milliseconds: 40),
);

/// Transition back to rest and into focus or disabled, the same 120ms ease as
/// `AcmeCard`.
final acmeBaseButtonRestMotion = AnimationConfig.ease(
  const Duration(milliseconds: 120),
);

/// Shared Acme BaseButton metrics used by Button and IconButton recipes.
({
  double height,
  double paddingX,
  double gap,
  Radius radius,
  TextStyleToken text,
  double spinnerSize,
})
acmeBaseButtonMetrics(AcmeBaseButtonSize size) => switch (size) {
  .size1 => (
    height: AcmeTokens.space5(),
    paddingX: AcmeTokens.space2(),
    gap: AcmeTokens.space1(),
    radius: AcmeTokens.radius1OrFull(),
    text: AcmeTokens.text1,
    spinnerSize: AcmeTokens.space3(),
  ),
  .size2 => (
    height: AcmeTokens.space6(),
    paddingX: AcmeTokens.space3(),
    gap: AcmeTokens.space2(),
    radius: AcmeTokens.radius2OrFull(),
    text: AcmeTokens.text2,
    spinnerSize: AcmeTokens.space4(),
  ),
  .size3 => (
    height: AcmeTokens.space7(),
    paddingX: AcmeTokens.space4(),
    gap: AcmeTokens.space3(),
    radius: AcmeTokens.radius3OrFull(),
    text: AcmeTokens.text3,
    spinnerSize: AcmeTokens.space4(),
  ),
  .size4 => (
    height: AcmeTokens.space8(),
    paddingX: AcmeTokens.space5(),
    gap: AcmeTokens.space3(),
    radius: AcmeTokens.radius4OrFull(),
    text: AcmeTokens.text4,
    spinnerSize: AcmeTokens.spinnerSize3(),
  ),
};

/// Default icon dimensions shared by text and icon-only button presets.
double acmeBaseButtonIconSize(AcmeBaseButtonSize size) => switch (size) {
  .size1 => AcmeTokens.space3(),
  .size2 => AcmeTokens.space4(),
  .size3 => AcmeTokens.spinnerSize3(),
  .size4 => AcmeTokens.space5(),
};

/// Content-box metrics for the ghost BaseButton variant.
({double paddingX, double paddingY, double marginX, double marginY, double gap})
acmeBaseButtonGhostMetrics(AcmeBaseButtonSize size) => switch (size) {
  .size1 => (
    paddingX: AcmeTokens.space2(),
    paddingY: AcmeTokens.space1(),
    marginX: AcmeTokens.baseButtonGhostMarginX12(),
    marginY: AcmeTokens.baseButtonGhostMarginY12(),
    gap: AcmeTokens.space1(),
  ),
  .size2 => (
    paddingX: AcmeTokens.space2(),
    paddingY: AcmeTokens.space1(),
    marginX: AcmeTokens.baseButtonGhostMarginX12(),
    marginY: AcmeTokens.baseButtonGhostMarginY12(),
    gap: AcmeTokens.space1(),
  ),
  .size3 => (
    paddingX: AcmeTokens.space3(),
    paddingY: AcmeTokens.space2(),
    marginX: AcmeTokens.baseButtonGhostMarginX3(),
    marginY: AcmeTokens.baseButtonGhostMarginY3(),
    gap: AcmeTokens.space2(),
  ),
  .size4 => (
    paddingX: AcmeTokens.space4(),
    paddingY: AcmeTokens.space2(),
    marginX: AcmeTokens.baseButtonGhostMarginX4(),
    marginY: AcmeTokens.baseButtonGhostMarginY4(),
    gap: AcmeTokens.space2(),
  ),
};

/// Content-box metrics for the ghost IconButton variant.
({double padding, double margin}) acmeIconButtonGhostMetrics(
  AcmeBaseButtonSize size,
) => switch (size) {
  .size1 => (
    padding: AcmeTokens.space1(),
    margin: AcmeTokens.iconButtonGhostMargin1(),
  ),
  .size2 => (
    padding: AcmeTokens.space2(),
    margin: AcmeTokens.iconButtonGhostMargin2(),
  ),
  .size3 => (
    padding: AcmeTokens.space2(),
    margin: AcmeTokens.iconButtonGhostMargin3(),
  ),
  .size4 => (
    padding: AcmeTokens.space3(),
    margin: AcmeTokens.iconButtonGhostMargin4(),
  ),
};

/// Resolves a mode-aware ordered CSS filter at the component build context.
WidgetModifierConfig acmeModeAwareFilter({
  required List<RemixCssColorFilterOperation> light,
  required List<RemixCssColorFilterOperation> dark,
}) => WidgetModifierConfig.modifier(
  _AcmeModeAwareFilterMix(light: light, dark: dark),
);

/// Explicit identity filter used to clear a higher-priority state filter.
WidgetModifierConfig acmeClearFilter() =>
    acmeModeAwareFilter(light: const [], dark: const []);

final class _AcmeModeAwareFilterMix
    extends ModifierMix<RemixOrderedColorFilterModifier> {
  const _AcmeModeAwareFilterMix({required this.light, required this.dark});

  final List<RemixCssColorFilterOperation> light;
  final List<RemixCssColorFilterOperation> dark;

  @override
  RemixOrderedColorFilterModifier resolve(BuildContext context) =>
      RemixOrderedColorFilterModifier(
        AcmeTheme.of(context).isDark ? dark : light,
      );

  @override
  _AcmeModeAwareFilterMix merge(_AcmeModeAwareFilterMix? other) =>
      other ?? this;

  @override
  List<Object?> get props => [light, dark];
}

/// Shared Acme BaseButton variants implemented by Button and IconButton.
enum AcmeBaseButtonVariant { solid, soft, surface, outline, ghost }

/// One visual-state style fragment from the shared BaseButton recipe.
final class AcmeBaseButtonStateStyle {
  const AcmeBaseButtonStateStyle({
    this.foreground,
    this.background,
    this.effects,
    this.modifier,
    this.spinnerOpacity,
  });

  final Color? foreground;
  final Color? background;
  final RemixBoxEffectsMix? effects;
  final WidgetModifierConfig? modifier;
  final double? spinnerOpacity;
}

/// Visual state styles shared by the concrete Button and IconButton stylers.
final class AcmeBaseButtonStateStyles {
  const AcmeBaseButtonStateStyles({
    required this.idle,
    required this.hovered,
    required this.pressed,
    required this.disabled,
    required this.focusVisible,
    required this.disabledFocus,
  });

  final AcmeBaseButtonStateStyle idle;
  final AcmeBaseButtonStateStyle hovered;
  final AcmeBaseButtonStateStyle pressed;
  final AcmeBaseButtonStateStyle disabled;
  final AcmeBaseButtonStateStyle focusVisible;
  final AcmeBaseButtonStateStyle disabledFocus;
}

AcmeBaseButtonStateStyles acmeBaseButtonStateStyles({
  required AcmeBaseButtonVariant variant,
  required bool highContrast,
}) {
  final states = switch (variant) {
    .solid => _solidStateStyles(highContrast: highContrast),
    .soft => _softStateStyles(highContrast: highContrast),
    .surface => _surfaceStateStyles(highContrast: highContrast),
    .outline => _outlineStateStyles(highContrast: highContrast),
    .ghost => _ghostStateStyles(highContrast: highContrast),
  };

  return AcmeBaseButtonStateStyles(
    idle: states.idle,
    hovered: states.hovered,
    pressed: states.pressed,
    disabled: states.disabled,
    focusVisible: AcmeBaseButtonStateStyle(effects: acmeFocusOutline()),
    disabledFocus: AcmeBaseButtonStateStyle(
      effects: RemixBoxEffectsMix.outline(
        BorderSideMix(style: BorderStyle.none),
      ),
    ),
  );
}

typedef _InteractionStateStyles = ({
  AcmeBaseButtonStateStyle idle,
  AcmeBaseButtonStateStyle hovered,
  AcmeBaseButtonStateStyle pressed,
  AcmeBaseButtonStateStyle disabled,
});

_InteractionStateStyles _solidStateStyles({required bool highContrast}) {
  final foreground = highContrast
      ? AcmeTokens.gray1()
      : AcmeTokens.accentContrast();

  return (
    idle: AcmeBaseButtonStateStyle(
      foreground: foreground,
      background: highContrast ? AcmeTokens.accent12() : AcmeTokens.accent9(),
    ),
    hovered: AcmeBaseButtonStateStyle(
      background: highContrast ? AcmeTokens.accent12() : AcmeTokens.accent10(),
      modifier: _hoverFilter(highContrast),
    ),
    pressed: AcmeBaseButtonStateStyle(
      background: highContrast ? AcmeTokens.accent12() : AcmeTokens.accent10(),
      modifier: _pressedFilter(highContrast),
    ),
    disabled: AcmeBaseButtonStateStyle(
      foreground: AcmeTokens.grayA8(),
      background: AcmeTokens.grayA3(),
      spinnerOpacity: 1,
      modifier: acmeClearFilter(),
    ),
  );
}

_InteractionStateStyles _softStateStyles({required bool highContrast}) => (
  idle: AcmeBaseButtonStateStyle(
    foreground: highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
    background: AcmeTokens.accentA3(),
  ),
  hovered: AcmeBaseButtonStateStyle(background: AcmeTokens.accentA4()),
  pressed: AcmeBaseButtonStateStyle(background: AcmeTokens.accentA5()),
  disabled: AcmeBaseButtonStateStyle(
    foreground: AcmeTokens.grayA8(),
    background: AcmeTokens.grayA3(),
    spinnerOpacity: 1,
  ),
);

_InteractionStateStyles _surfaceStateStyles({required bool highContrast}) => (
  idle: AcmeBaseButtonStateStyle(
    foreground: highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
    background: AcmeTokens.accentSurface(),
    effects: RemixBoxEffectsMix.behindContent(
      acmeInsetSurface(strokes: [AcmeTokens.accentA7()]),
    ),
  ),
  hovered: AcmeBaseButtonStateStyle(
    background: AcmeTokens.accentSurface(),
    effects: RemixBoxEffectsMix.behindContent(
      acmeInsetSurface(strokes: [AcmeTokens.accentA8()]),
    ),
  ),
  pressed: AcmeBaseButtonStateStyle(
    background: AcmeTokens.accentA3(),
    effects: RemixBoxEffectsMix.behindContent(
      acmeInsetSurface(strokes: [AcmeTokens.accentA8()]),
    ),
  ),
  disabled: AcmeBaseButtonStateStyle(
    foreground: AcmeTokens.grayA8(),
    background: AcmeTokens.grayA2(),
    effects: RemixBoxEffectsMix.behindContent(
      acmeInsetSurface(strokes: [AcmeTokens.grayA6()]),
    ),
    spinnerOpacity: 1,
  ),
);

_InteractionStateStyles _outlineStateStyles({required bool highContrast}) {
  final strokes = highContrast
      ? [AcmeTokens.accentA7(), AcmeTokens.grayA11()]
      : [AcmeTokens.accentA8()];
  final effects = RemixBoxEffectsMix.behindContent(
    acmeInsetSurface(strokes: strokes),
  );

  return (
    idle: AcmeBaseButtonStateStyle(
      foreground: highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
      effects: effects,
    ),
    hovered: AcmeBaseButtonStateStyle(
      background: AcmeTokens.accentA2(),
      effects: effects,
    ),
    pressed: AcmeBaseButtonStateStyle(
      background: AcmeTokens.accentA3(),
      effects: effects,
    ),
    disabled: AcmeBaseButtonStateStyle(
      foreground: AcmeTokens.grayA8(),
      background: const Color(0x00000000),
      effects: RemixBoxEffectsMix.behindContent(
        acmeInsetSurface(strokes: [AcmeTokens.grayA7()]),
      ),
      spinnerOpacity: 1,
    ),
  );
}

_InteractionStateStyles _ghostStateStyles({required bool highContrast}) => (
  idle: AcmeBaseButtonStateStyle(
    foreground: highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
    background: const Color(0x00000000),
  ),
  hovered: AcmeBaseButtonStateStyle(background: AcmeTokens.accentA3()),
  pressed: AcmeBaseButtonStateStyle(background: AcmeTokens.accentA4()),
  disabled: AcmeBaseButtonStateStyle(
    foreground: AcmeTokens.grayA8(),
    background: const Color(0x00000000),
    spinnerOpacity: 1,
  ),
);

WidgetModifierConfig _hoverFilter(bool highContrast) {
  if (!highContrast) return acmeClearFilter();

  return acmeModeAwareFilter(
    light: const [
      RemixCssColorFilterOperation.contrast(0.88),
      RemixCssColorFilterOperation.saturate(1.1),
      RemixCssColorFilterOperation.brightness(1.1),
    ],
    dark: const [
      RemixCssColorFilterOperation.contrast(0.88),
      RemixCssColorFilterOperation.saturate(1.3),
      RemixCssColorFilterOperation.brightness(1.18),
    ],
  );
}

WidgetModifierConfig _pressedFilter(bool highContrast) {
  if (highContrast) {
    return acmeModeAwareFilter(
      light: const [
        RemixCssColorFilterOperation.contrast(0.82),
        RemixCssColorFilterOperation.saturate(1.2),
        RemixCssColorFilterOperation.brightness(1.16),
      ],
      dark: const [
        RemixCssColorFilterOperation.brightness(0.95),
        RemixCssColorFilterOperation.saturate(1.2),
      ],
    );
  }

  return acmeModeAwareFilter(
    light: const [
      RemixCssColorFilterOperation.brightness(0.92),
      RemixCssColorFilterOperation.saturate(1.1),
    ],
    dark: const [RemixCssColorFilterOperation.brightness(1.08)],
  );
}
