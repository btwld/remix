import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'checkbox.g.dart';

/// Acme Checkbox size presets.
enum AcmeCheckboxSize { size1, size2, size3 }

/// Acme Checkbox variants.
enum AcmeCheckboxVariant { surface, soft }

/// Acme recipe for [RemixCheckbox].
@MixWidget(target: RemixCheckbox.new)
CheckboxStyler acmeCheckboxStyle({
  AcmeCheckboxVariant variant = .surface,
  AcmeCheckboxSize size = .size2,
  bool highContrast = false,
  CheckboxStyler style = const CheckboxStyler.create(),
}) {
  final metrics = _acmeCheckboxMetrics(size);
  final base = CheckboxStyler(
    container: .size(
      metrics.size,
      metrics.size,
    ).alignment(.center).borderRadius(.all(metrics.radius)),
    indicator: .size(metrics.indicatorSize),
    containerEffects: RemixBoxEffectsMix(
      behindContent: RemixBoxEffectLayerMix(),
      overContent: RemixBoxEffectLayerMix(),
    ),
  ).onFocusVisible(.containerEffects(acmeFocusOutline()));

  return (switch (variant) {
        .surface => _acmeCheckboxSurface(base, highContrast),
        .soft => _acmeCheckboxSoft(base, highContrast),
      })
      .wrap(acmeTouchTarget())
      .onDisabled(
        CheckboxStyler().containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      .merge(style);
}

/// Acme recipe for [RemixCheckboxGroupItem].
///
///
/// It exists because `RemixCheckboxGroup` is behavioral and carries no styler,
/// so unlike every other Remix item (menu, select, segmented control, toggle
/// group) there is no parent recipe to push item styling down. Without this,
/// callers hand-attach a styler to each item and a missed one in a loop renders
/// unstyled beside its styled siblings.
@MixWidget(target: RemixCheckboxGroupItem.new)
CheckboxStyler acmeCheckboxGroupItemStyle({
  AcmeCheckboxVariant variant = .surface,
  AcmeCheckboxSize size = .size2,
  bool highContrast = false,
  CheckboxStyler style = const CheckboxStyler.create(),
}) {
  final checkbox = acmeCheckboxStyle(
    variant: variant,
    size: size,
    highContrast: highContrast,
  );

  return (switch (size) {
        .size1 =>
          checkbox
              .label(.style(AcmeTokens.text1.mix()))
              .labelSpacing(AcmeTokens.space1()),
        .size2 =>
          checkbox
              .label(.style(AcmeTokens.text2.mix()))
              .labelSpacing(AcmeTokens.space2()),
        .size3 =>
          checkbox
              .label(.style(AcmeTokens.text3.mix()))
              .labelSpacing(AcmeTokens.space2()),
      })
      .wrap(acmeTouchTarget())
      .onDisabled(
        CheckboxStyler().containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      .merge(style);
}

({double size, double indicatorSize, Radius radius}) _acmeCheckboxMetrics(
  AcmeCheckboxSize size,
) => switch (size) {
  .size1 => (
    size: AcmeTokens.checkboxSize1(),
    indicatorSize: AcmeTokens.checkboxIndicatorSize1(),
    radius: AcmeTokens.checkboxRadius1(),
  ),
  .size2 => (
    size: AcmeTokens.space4(),
    indicatorSize: AcmeTokens.checkboxIndicatorSize2(),
    radius: AcmeTokens.radius1(),
  ),
  .size3 => (
    size: AcmeTokens.checkboxSize3(),
    indicatorSize: AcmeTokens.space3(),
    radius: AcmeTokens.checkboxRadius3(),
  ),
};

CheckboxStyler _acmeCheckboxSurface(CheckboxStyler base, bool highContrast) {
  final selected = CheckboxStyler()
      .color(
        highContrast ? AcmeTokens.accent12() : AcmeTokens.accentIndicator(),
      )
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(shadows: const []),
        ),
      )
      .indicatorColor(
        highContrast ? AcmeTokens.accent1() : AcmeTokens.accentContrast(),
      );

  return base
      .color(AcmeTokens.colorSurface())
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          acmeInsetSurface(strokes: [AcmeTokens.grayA7()]),
        ),
      )
      .onSelected(selected)
      .onIndeterminate(selected)
      .onDisabled(
        .color(AcmeTokens.grayA3())
            .containerEffects(
              RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
            )
            .containerEffects(
              RemixBoxEffectsMix.overContent(
                acmeInsetSurface(strokes: [AcmeTokens.grayA6()]),
              ),
            )
            .indicatorColor(AcmeTokens.grayA8()),
      );
}

CheckboxStyler _acmeCheckboxSoft(CheckboxStyler base, bool highContrast) {
  final selected = CheckboxStyler().indicatorColor(
    highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
  );

  return base
      .color(AcmeTokens.accentA5())
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .onSelected(selected)
      .onIndeterminate(selected)
      .onDisabled(
        .color(AcmeTokens.grayA3())
            .containerEffects(
              RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
            )
            .indicatorColor(AcmeTokens.grayA8()),
      );
}
