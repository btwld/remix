import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'tooltip.g.dart';

/// Acme-themed preset for [RemixTooltip].
@MixWidget(target: RemixTooltip.new)
TooltipStyler acmeTooltipStyle({
  TooltipStyler style = const TooltipStyler.create(),
}) {
  return TooltipStyler(
        label: .style(AcmeTokens.text1.mix()),
        waitDuration: const Duration(milliseconds: 200),
      )
      .borderRadius(.all(AcmeTokens.radius2()))
      .padding(.vertical(AcmeTokens.space1()))
      .padding(.horizontal(AcmeTokens.space2()))
      .label(.color(AcmeTokens.gray1()))
      .color(AcmeTokens.gray12())
      .decoration(BoxDecorationMix.create(boxShadow: AcmeTokens.shadow3.mix()))
      .merge(style);
}
