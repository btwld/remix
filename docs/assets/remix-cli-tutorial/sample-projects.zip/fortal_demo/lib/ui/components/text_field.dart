// `DragStartBehavior` and `MaxLengthEnforcement` appear in the generated
// AcmeTextField/AcmeTextArea constructors, so they must be visible from
// this library even though nothing here references them directly.
import 'package:flutter/gestures.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'text_field.g.dart';

/// The sizes a text field comes in. Pixel values are at 100% theme scaling.
enum AcmeTextFieldSize {
  /// 24px tall, with 12px text.
  size1,

  /// 32px tall, with 14px text. The default.
  size2,

  /// 40px tall, with 16px text.
  size3,
}

/// The looks a text field comes in.
enum AcmeTextFieldVariant {
  /// The `gray2` fill inside a 1px neutral frame, with neutral text.
  surface,

  /// An accent tint inside a 1px accent ring, with accent-colored text.
  soft,
}

/// The Fortal TextField recipe.
///
/// It reads top to bottom: what every text input shares, then the size, then
/// the variant's colors for rest and disabled, then the error state.
@MixWidget(target: RemixTextField.new)
TextFieldStyler acmeTextFieldStyle({
  AcmeTextFieldVariant variant = .surface,
  AcmeTextFieldSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) => _input(
  size: _fieldSize(size),
  look: switch (variant) {
    .surface => _surface(),
    .soft => _soft(),
  },
).merge(style);

/// The sizes a text area comes in. Pixel values are at 100% theme scaling.
enum AcmeTextAreaSize {
  /// At least 48px tall, with 12px text.
  size1,

  /// At least 64px tall, with 14px text. The default.
  size2,

  /// At least 80px tall, with 16px text.
  size3,
}

/// The Fortal TextArea recipe: the text field's looks on a taller box whose
/// content starts at the top.
@MixWidget(target: RemixTextArea.new)
TextFieldStyler acmeTextAreaStyle({
  AcmeTextFieldVariant variant = .surface,
  AcmeTextAreaSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) => _input(
  size: _areaSize(size),
  look: switch (variant) {
    .surface => _surface(),
    .soft => _soft(),
  },
).merge(style);

/// A text field or area: the shared base, then [size] and [look], then the
/// error and disabled states.
TextFieldStyler _input({
  required TextFieldStyler size,
  required TextFieldStyler look,
}) => _base()
    .merge(size)
    .merge(look)
    .variant(ContextVariant.widgetState(.error), _error())
    .onDisabled(.containerEffects(.outline(.style(.none))))
    // The input container sits inside Remix's chrome gesture detector.
    // An outer wrapper would reserve space without accepting its taps.
    .container(BoxStyler().wrap(acmeTouchTarget()));

/// What every text input shares: label and helper text, cursor, icon color,
/// and the focus ring.
///
/// The empty effect layers give the variant's state fragments layers to
/// replace.
TextFieldStyler _base() =>
    TextFieldStyler(
          helperText: .style(AcmeTokens.text1.mix()),
          label: .style(AcmeTokens.text2.mix()),
          cursorWidth: 1.5,
          containerEffects: RemixBoxEffectsMix(
            behindContent: RemixBoxEffectLayerMix(),
            overContent: RemixBoxEffectLayerMix(),
          ),
        )
        .wrap(.iconTheme(color: AcmeTokens.gray11(), size: AcmeTokens.space4()))
        // A text input rings on any focus, as a browser does.
        .onFocused(.containerEffects(acmeFocusOutline()));

/// The box and text of a text field: one line, centered.
TextFieldStyler _fieldSize(AcmeTextFieldSize size) {
  final (:height, :paddingX, :spacing, :radius, :text) = switch (size) {
    .size1 => (
      height: AcmeTokens.space5(),
      paddingX: AcmeTokens.space2(),
      spacing: AcmeTokens.space2(),
      radius: AcmeTokens.radius2OrFull(),
      text: AcmeTokens.text1,
    ),
    .size2 => (
      height: AcmeTokens.space6(),
      paddingX: AcmeTokens.space2(),
      spacing: AcmeTokens.space2(),
      radius: AcmeTokens.radius2OrFull(),
      text: AcmeTokens.text2,
    ),
    .size3 => (
      height: AcmeTokens.space7(),
      paddingX: AcmeTokens.space3(),
      spacing: AcmeTokens.space3(),
      radius: AcmeTokens.radius3OrFull(),
      text: AcmeTokens.text3,
    ),
  };

  return _sized(
    minHeight: height,
    paddingX: paddingX,
    paddingY: _fieldPaddingY(size)(),
    spacing: spacing,
    radius: radius,
    crossAxisAlignment: .center,
    text: text,
  );
}

/// The box and text of a text area: at least a few lines, starting at the top.
TextFieldStyler _areaSize(AcmeTextAreaSize size) {
  final (
    :minHeight,
    :paddingX,
    :paddingY,
    :spacing,
    :radius,
    :text,
  ) = switch (size) {
    .size1 => (
      minHeight: AcmeTokens.space8(),
      paddingX: AcmeTokens.space2(),
      paddingY: AcmeTokens.space1(),
      spacing: AcmeTokens.space2(),
      radius: AcmeTokens.radius2(),
      text: AcmeTokens.text1,
    ),
    .size2 => (
      minHeight: AcmeTokens.space9(),
      paddingX: AcmeTokens.space2(),
      paddingY: AcmeTokens.space2(),
      spacing: AcmeTokens.space2(),
      radius: AcmeTokens.radius2(),
      text: AcmeTokens.text2,
    ),
    .size3 => (
      minHeight: AcmeTokens.textAreaMinHeight3(),
      paddingX: AcmeTokens.space3(),
      paddingY: AcmeTokens.space2(),
      spacing: AcmeTokens.space3(),
      radius: AcmeTokens.radius3(),
      text: AcmeTokens.text3,
    ),
  };

  return _sized(
    minHeight: minHeight,
    paddingX: paddingX,
    paddingY: paddingY,
    spacing: spacing,
    radius: radius,
    crossAxisAlignment: .start,
    text: text,
  );
}

/// A text input's box and its text and hint style.
///
/// The hint keeps its line height at the bottom of the line only, so the
/// placeholder sits where typed text will.
TextFieldStyler _sized({
  required double minHeight,
  required double paddingX,
  required double paddingY,
  required double spacing,
  required Radius radius,
  required CrossAxisAlignment crossAxisAlignment,
  required TextStyleToken text,
}) => TextFieldStyler(
  container: BoxStyler()
      .minHeight(minHeight)
      .padding(.symmetric(horizontal: paddingX, vertical: paddingY))
      .borderRadius(.all(radius))
      .clipBehavior(.antiAlias),
  spacing: spacing,
  crossAxisAlignment: crossAxisAlignment,
  text: .style(text.mix()),
  hintText: .style(text.mix()).textHeightBehavior(
    TextHeightBehaviorMix()
        .applyHeightToFirstAscent(false)
        .applyHeightToLastDescent(true),
  ),
);

/// Vertical padding that centers one line of text in a field's height.
///
/// This keeps the 24, 32 and 40px field heights and a centered baseline at 1x,
/// while leaving the text line unconstrained as MediaQuery text scaling
/// increases. The frame is an inset effect, not a layout-consuming border.
ContextToken<double> _fieldPaddingY(AcmeTextFieldSize size) =>
    ContextToken<double>((context) {
      final (height, text) = switch (size) {
        .size1 => (AcmeTokens.space5, AcmeTokens.text1),
        .size2 => (AcmeTokens.space6, AcmeTokens.text2),
        .size3 => (AcmeTokens.space7, AcmeTokens.text3),
      };
      final style = text.resolve(context);

      return (height.resolve(context) - style.fontSize! * style.height!) / 2;
    });

/// The `gray2` fill with a neutral frame and neutral text.
TextFieldStyler _surface() =>
    TextFieldStyler(
          text: .color(
            AcmeTokens.gray12(),
          ).selectionColor(AcmeTokens.focusA5()),
          hintText: .color(AcmeTokens.grayA11()),
          cursorColor: AcmeTokens.gray12(),
          helperText: .color(AcmeTokens.gray11()),
          label: .color(
            AcmeTokens.gray12(),
          ).fontWeight(AcmeTokens.fontWeightMedium()),
        )
        .color(AcmeTokens.gray2())
        // An unlabeled field relies on its border to be found at all.
        .merge(
          _effects(
            over: acmeInsetSurface(strokes: [AcmeTokens.controlBorder()]),
          ),
        )
        .onDisabled(
          _disabledText()
              .hintText(.color(_disabledNeutralPlaceholder()))
              .color(AcmeTokens.gray2())
              .merge(
                _effects(
                  behind: RemixBoxEffectLayerMix(
                    gradients: [
                      RemixLinearGradientMix(
                        colors: [AcmeTokens.grayA2(), AcmeTokens.grayA2()],
                      ),
                    ],
                  ),
                  over: acmeInsetSurface(strokes: [AcmeTokens.grayA6()]),
                ),
              ),
        );

/// An accent tint with accent-colored text and a regular weight.
TextFieldStyler _soft() =>
    TextFieldStyler(
          text: .fontWeight(AcmeTokens.fontWeightRegular()),
          hintText: .fontWeight(AcmeTokens.fontWeightRegular()),
          cursorColor: AcmeTokens.accent12(),
          helperText: .color(
            AcmeTokens.gray11(),
          ).fontWeight(AcmeTokens.fontWeightRegular()),
          label: .color(
            AcmeTokens.gray12(),
          ).fontWeight(AcmeTokens.fontWeightMedium()),
        )
        .textColor(AcmeTokens.accent12())
        .text(.selectionColor(AcmeTokens.accentA5()))
        .onEnabled(.hintText(.color(AcmeTokens.accentContentAlpha())))
        // Base-level icon overrides remain available while enabled.
        .wrap(.iconTheme(color: AcmeTokens.accentContent()))
        .color(AcmeTokens.accentA3())
        // A blank soft field shows no text, hint or border of its own, and its
        // tint alone is far below 3:1; the accent-8 ring keeps it findable. It
        // is the base so caller base overrides still win; disabled clears it.
        .merge(_effects(over: acmeInsetSurface(strokes: [AcmeTokens.focus8()])))
        .onDisabled(
          _disabledText()
              .hintText(.color(_disabledSoftPlaceholder()))
              .wrap(.iconTheme(color: AcmeTokens.accent10()))
              .color(AcmeTokens.grayA3())
              .merge(_effects(over: RemixBoxEffectLayerMix(shadows: const []))),
        );

/// Gray text and cursor for a disabled input, with no focus ring.
///
/// The disabled colors apply on raw focus too, matching the enabled input's
/// `:focus-within` behavior.
TextFieldStyler _disabledText() => TextFieldStyler(
  text: .color(AcmeTokens.grayA11()).selectionColor(AcmeTokens.grayA5()),
  cursorColor: AcmeTokens.grayA11(),
).containerEffects(RemixBoxEffectsMix(outline: BorderSideMix(style: .none)));

/// The error ring and text colors, shown over whichever variant is active.
TextFieldStyler _error() => TextFieldStyler(
  helperText: .color(AcmeTokens.error11()),
  label: .color(AcmeTokens.error11()),
  cursorColor: AcmeTokens.error9(),
  containerEffects: RemixBoxEffectsMix(
    overContent: RemixBoxEffectLayerMix(
      shadows: [
        RemixBoxShadowMix(
          kind: .inset,
          color: AcmeTokens.error8(),
          spreadRadius: AcmeTokens.borderWidth1(),
        ),
      ],
    ),
  ),
);

/// Sets the layer [over] the content, and empties the layer behind it or sets
/// [behind].
TextFieldStyler _effects({
  RemixBoxEffectLayerMix? behind,
  required RemixBoxEffectLayerMix over,
}) => TextFieldStyler()
    .containerEffects(
      RemixBoxEffectsMix.behindContent(behind ?? RemixBoxEffectLayerMix()),
    )
    .containerEffects(RemixBoxEffectsMix.overContent(over));

/// The hint color of a disabled neutral input: gray-alpha-10 at half opacity.
final _disabledNeutralPlaceholder = ContextToken<Color>((context) {
  final color = AcmeTokens.grayA10.resolve(context);

  return color.withValues(alpha: color.a * 0.5);
});

/// The hint color of a disabled soft input: accent step 12 at half opacity.
final _disabledSoftPlaceholder = ContextToken<Color>(
  (context) => AcmeTokens.accent12.resolve(context).withValues(alpha: 0.5),
);
