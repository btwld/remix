import 'dart:math' as math;

import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'dialog.g.dart';

/// The sizes a dialog comes in, from its padding and corners. Pixel values are
/// at 100% theme scaling.
enum AcmeDialogSize {
  /// 12px padding.
  size1,

  /// 16px padding.
  size2,

  /// 24px padding. The default.
  size3,

  /// 32px padding.
  size4,
}

/// Padding that keeps the dialog off the screen edges: 16px at the sides and
/// 32px at the top and bottom, or the safe area when that is larger. The
/// bottom keeps at least 6% of the viewport height.
final _dialogViewportInsets = ContextToken<EdgeInsetsGeometry>((context) {
  final safeArea = MediaQuery.paddingOf(context);
  final viewportHeight = MediaQuery.sizeOf(context).height;
  final horizontal = AcmeTokens.space4.resolve(context);
  final vertical = AcmeTokens.space6.resolve(context);

  return EdgeInsets.fromLTRB(
    math.max(safeArea.left, horizontal),
    math.max(safeArea.top, vertical),
    math.max(safeArea.right, horizontal),
    math.max(safeArea.bottom, math.max(vertical, viewportHeight * 0.06)),
  );
});

/// The Fortal Dialog recipe: a raised, blurred panel with a bold title.
///
/// The generated [AcmeDialog] defaults to [AcmeDialogSize.size3],
/// [Alignment.center], fills up to 600 logical pixels, preserves safe
/// viewport insets, and is modal.
@MixWidget(target: RemixDialog.new)
DialogStyler acmeDialogStyle({
  AcmeDialogSize size = .size3,
  AlignmentGeometry align = Alignment.center,
  DialogStyler style = const DialogStyler.create(),
}) {
  final radius = switch (size) {
    .size1 || .size2 => AcmeTokens.radius4(),
    .size3 || .size4 => AcmeTokens.radius5(),
  };
  final padding = switch (size) {
    .size1 => AcmeTokens.space3(),
    .size2 => AcmeTokens.space4(),
    .size3 => AcmeTokens.space5(),
    .size4 => AcmeTokens.space6(),
  };

  return DialogStyler()
      .wrap(
        .modifier(
          PaddingModifierMix.create(padding: Prop.token(_dialogViewportInsets)),
        ).align(alignment: align).orderOfModifiers([
          PaddingModifier,
          AlignModifier,
        ]),
      )
      .title(
        .style(AcmeTokens.text5.mix())
            .fontWeight(AcmeTokens.fontWeightBold())
            .color(AcmeTokens.gray12())
            .wrap(
              .padding(EdgeInsetsMix.fromLTRB(0, 0, 0, AcmeTokens.space3())),
            ),
      )
      .description(
        TextStyler(style: AcmeTokens.text3.mix()).color(AcmeTokens.gray12()),
      )
      .actions(
        FlexBoxStyler()
            .mainAxisAlignment(.end)
            .spacing(AcmeTokens.space3())
            .margin(.top(AcmeTokens.space5())),
      )
      .width(AcmeTokens.dialogMaxWidth())
      .padding(.all(padding))
      .borderRadius(.all(radius))
      .color(AcmeTokens.colorPanel())
      .decoration(BoxDecorationMix.create(boxShadow: AcmeTokens.shadow6.mix()))
      .containerEffects(RemixBoxEffectsMix.backdropBlur(AcmeTokens.panelBlur()))
      .merge(style);
}
