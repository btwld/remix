// `DragStartBehavior` and `MaxLengthEnforcement` appear in the generated
// AcmeTextField/AcmeTextArea constructors, so they must be visible from
// this library even though nothing here references them directly.
import 'package:flutter/gestures.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'textfield.g.dart';

/// Acme text field size presets.
enum AcmeTextFieldSize {
  /// Compact text field.
  size1,

  /// Default text field.
  size2,

  /// Large text field.
  size3,
}

/// Acme text field color variants.
enum AcmeTextFieldVariant {
  /// Surface treatment with neutral border and text colors.
  surface,

  /// Soft accent treatment.
  soft,
}

Color _resolveDisabledNeutralTextInputPlaceholder(BuildContext context) {
  final color = AcmeTokens.grayA10.resolve(context);
  return color.withValues(alpha: color.a * 0.5);
}

const _disabledNeutralTextInputPlaceholder = ContextToken<Color>(
  _resolveDisabledNeutralTextInputPlaceholder,
);

final _softTextInputDisabledPlaceholder = ContextToken<Color>(
  (context) => AcmeTokens.accent12.resolve(context).withValues(alpha: 0.5),
);

/// Acme-themed preset for [RemixTextField].
@MixWidget(target: RemixTextField.new)
TextFieldStyler acmeTextFieldStyle({
  AcmeTextFieldVariant variant = .surface,
  AcmeTextFieldSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) {
  final metrics = _acmeTextFieldMetrics(size, bordered: variant != .soft);
  final base = _acmeTextInputBaseStyle(
    container: BoxStyler()
        .height(metrics.height)
        .padding(.horizontal(metrics.paddingX))
        .borderRadius(.all(metrics.radius))
        .clipBehavior(.antiAlias),
    spacing: metrics.spacing,
    crossAxisAlignment: .center,
    text: metrics.text,
  );

  final recipe = switch (variant) {
    .surface => _acmeApplySurfaceTextInput(base),
    .soft => _acmeApplySoftTextInput(base),
  };

  return recipe
      .variant(ContextVariant.widgetState(.error), _acmeTextInputErrorStyle())
      .onDisabled(
        .containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      // The input container sits inside Remix's chrome gesture detector.
      // An outer wrapper would reserve space without accepting its taps.
      .container(BoxStyler().wrap(acmeTouchTarget()))
      .merge(style);
}

TextFieldStyler _acmeTextInputBaseStyle({
  required BoxStyler container,
  required double spacing,
  required CrossAxisAlignment crossAxisAlignment,
  required TextStyleToken text,
}) =>
    TextFieldStyler(
          container: container,
          spacing: spacing,
          crossAxisAlignment: crossAxisAlignment,
          text: .style(text.mix()),
          hintText: .style(text.mix()).textHeightBehavior(
            TextHeightBehaviorMix()
                .applyHeightToFirstAscent(false)
                .applyHeightToLastDescent(true),
          ),
          helperText: .style(AcmeTokens.text1.mix()),
          label: .style(AcmeTokens.text2.mix()),
          cursorWidth: 1.5,
          containerEffects: RemixBoxEffectsMix(
            behindContent: RemixBoxEffectLayerMix(),
            overContent: RemixBoxEffectLayerMix(),
          ),
        )
        .wrap(.iconTheme(color: AcmeTokens.gray11(), size: 16.0))
        .onFocused(.containerEffects(acmeFocusOutline()));

TextFieldStyler _acmeApplySurfaceTextInput(TextFieldStyler base) =>
    _acmeApplyNeutralTextInput(base)
        .color(AcmeTokens.gray2())
        .containerEffects(
          RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
        )
        // An unlabeled field relies on its border to be found at all.
        .containerEffects(
          RemixBoxEffectsMix.overContent(
            acmeInsetSurface(strokes: [AcmeTokens.controlBorder()]),
          ),
        )
        .onDisabled(
          _acmeNeutralTextInputDisabledStyle()
              .color(AcmeTokens.gray2())
              .containerEffects(
                RemixBoxEffectsMix.behindContent(
                  RemixBoxEffectLayerMix(
                    gradients: [
                      RemixLinearGradientMix(
                        colors: [AcmeTokens.grayA2(), AcmeTokens.grayA2()],
                      ),
                    ],
                  ),
                ),
              )
              .containerEffects(
                RemixBoxEffectsMix.overContent(
                  acmeInsetSurface(strokes: [AcmeTokens.grayA6()]),
                ),
              ),
        );

TextFieldStyler _acmeApplySoftTextInput(TextFieldStyler base) => base
    .merge(
      TextFieldStyler(
        text: .fontWeight(AcmeTokens.fontWeightRegular()),
        hintText: .fontWeight(AcmeTokens.fontWeightRegular()),
        cursorColor: AcmeTokens.accent12(),
        helperText: .color(
          AcmeTokens.gray11(),
        ).fontWeight(AcmeTokens.fontWeightRegular()),
        label: .color(
          AcmeTokens.gray12(),
        ).fontWeight(AcmeTokens.fontWeightMedium()),
      ),
    )
    .textColor(AcmeTokens.accent12())
    .text(.selectionColor(AcmeTokens.accentA5()))
    .onEnabled(.hintText(.color(AcmeTokens.accentContentAlpha())))
    // Base-level icon overrides remain available while enabled.
    .wrap(.iconTheme(color: AcmeTokens.accentContent()))
    .color(AcmeTokens.accentA3())
    .containerEffects(
      RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
    )
    // A blank soft field shows no text, hint or border of its own, and its
    // tint alone is far below 3:1; the accent-8 ring keeps it findable. It is
    // the base so caller base overrides still win; disabled clears it.
    .containerEffects(
      RemixBoxEffectsMix.overContent(
        acmeInsetSurface(strokes: [AcmeTokens.focus8()]),
      ),
    )
    .onDisabled(
      _acmeSoftTextInputDisabledStyle()
          .color(AcmeTokens.grayA3())
          .containerEffects(
            RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
          )
          .containerEffects(
            RemixBoxEffectsMix.overContent(
              RemixBoxEffectLayerMix(shadows: const []),
            ),
          ),
    );

TextFieldStyler _acmeApplyNeutralTextInput(TextFieldStyler base) => base.merge(
  TextFieldStyler(
    text: .color(AcmeTokens.gray12()).selectionColor(AcmeTokens.focusA5()),
    hintText: .color(AcmeTokens.grayA11()),
    cursorColor: AcmeTokens.gray12(),
    helperText: .color(AcmeTokens.gray11()),
    label: .color(
      AcmeTokens.gray12(),
    ).fontWeight(AcmeTokens.fontWeightMedium()),
  ),
);

// Keep the disabled-color branch on raw focus for the same :focus-within
// contract as the enabled text input.
TextFieldStyler _acmeTextInputDisabledBaseStyle() => TextFieldStyler(
  text: .color(AcmeTokens.grayA11()).selectionColor(AcmeTokens.grayA5()),
  cursorColor: AcmeTokens.grayA11(),
).containerEffects(RemixBoxEffectsMix(outline: BorderSideMix(style: .none)));

TextFieldStyler _acmeNeutralTextInputDisabledStyle() =>
    _acmeTextInputDisabledBaseStyle().hintText(
      .color(_disabledNeutralTextInputPlaceholder()),
    );

TextFieldStyler _acmeSoftTextInputDisabledStyle() =>
    _acmeTextInputDisabledBaseStyle()
        .hintText(.color(_softTextInputDisabledPlaceholder()))
        .wrap(.iconTheme(color: AcmeTokens.accent10()));

TextFieldStyler _acmeTextInputErrorStyle() => TextFieldStyler(
  helperText: .color(AcmeTokens.error11()),
  label: .color(AcmeTokens.error11()),
  cursorColor: AcmeTokens.error9(),
  containerEffects: RemixBoxEffectsMix(
    overContent: RemixBoxEffectLayerMix(
      shadows: [
        RemixBoxShadowMix(
          kind: .inset,
          color: AcmeTokens.error8(),
          spreadRadius: 1,
        ),
      ],
    ),
  ),
);

({
  double height,
  double paddingX,
  double spacing,
  Radius radius,
  TextStyleToken text,
})
_acmeTextFieldMetrics(AcmeTextFieldSize size, {required bool bordered}) =>
    switch (size) {
      .size1 => (
        height: AcmeTokens.space5(),
        paddingX: bordered ? AcmeTokens.space2() : AcmeTokens.space2(),
        spacing: AcmeTokens.space2(),
        radius: AcmeTokens.radius2OrFull(),
        text: AcmeTokens.text1,
      ),
      .size2 => (
        height: AcmeTokens.space6(),
        paddingX: bordered ? AcmeTokens.space2() : AcmeTokens.space2(),
        spacing: AcmeTokens.space2(),
        radius: AcmeTokens.radius2OrFull(),
        text: AcmeTokens.text2,
      ),
      .size3 => (
        height: AcmeTokens.space7(),
        paddingX: bordered ? AcmeTokens.space3() : AcmeTokens.space3(),
        spacing: AcmeTokens.space3(),
        radius: AcmeTokens.radius3OrFull(),
        text: AcmeTokens.text3,
      ),
    };

/// Acme TextArea size presets.
enum AcmeTextAreaSize { size1, size2, size3 }

/// Acme TextArea variants.
enum AcmeTextAreaVariant { surface, soft }

/// Acme recipe for [RemixTextArea].
@MixWidget(target: RemixTextArea.new)
TextFieldStyler acmeTextAreaStyle({
  AcmeTextAreaVariant variant = .surface,
  AcmeTextAreaSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) {
  final metrics = _acmeTextAreaMetrics(size);
  final base = _acmeTextInputBaseStyle(
    container: BoxStyler()
        .minHeight(metrics.minHeight)
        .padding(
          .symmetric(horizontal: metrics.paddingX, vertical: metrics.paddingY),
        )
        .borderRadius(.all(metrics.radius))
        .clipBehavior(.antiAlias),
    spacing: metrics.spacing,
    crossAxisAlignment: .start,
    text: metrics.text,
  );

  final recipe = switch (variant) {
    .surface => _acmeApplySurfaceTextInput(base),
    .soft => _acmeApplySoftTextInput(base),
  };

  return recipe
      .variant(ContextVariant.widgetState(.error), _acmeTextInputErrorStyle())
      .onDisabled(
        .containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      .container(BoxStyler().wrap(acmeTouchTarget()))
      .merge(style);
}

({
  double minHeight,
  double paddingX,
  double paddingY,
  double spacing,
  Radius radius,
  TextStyleToken text,
})
_acmeTextAreaMetrics(AcmeTextAreaSize size) => switch (size) {
  .size1 => (
    minHeight: AcmeTokens.space8(),
    paddingX: AcmeTokens.space2(),
    paddingY: AcmeTokens.space1(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2(),
    text: AcmeTokens.text1,
  ),
  .size2 => (
    minHeight: AcmeTokens.space9(),
    paddingX: AcmeTokens.space2(),
    paddingY: AcmeTokens.space2(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2(),
    text: AcmeTokens.text2,
  ),
  .size3 => (
    minHeight: AcmeTokens.textAreaMinHeight3(),
    paddingX: AcmeTokens.space3(),
    paddingY: AcmeTokens.space2(),
    spacing: AcmeTokens.space3(),
    radius: AcmeTokens.radius3(),
    text: AcmeTokens.text3,
  ),
};
