// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'text.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// Acme-themed body text on the Acme nine-step scale.
class AcmeText extends StatelessWidget {
  const AcmeText(
    this.text, {
    super.key,
    this.size,
    this.weight,
    this.align,
    this.softWrap = true,
    this.truncate = false,
    this.accent = false,
    this.highContrast = false,
    this.style = const TextStyler.create(),
  });

  final AcmeTextSize? size;

  final AcmeTextWeight? weight;

  final TextAlign? align;

  final bool softWrap;

  final bool truncate;

  final bool accent;

  final bool highContrast;

  final TextStyler style;

  final String text;

  @override
  Widget build(BuildContext _) {
    return acmeTextStyle(
      size: size,
      weight: weight,
      align: align,
      softWrap: softWrap,
      truncate: truncate,
      accent: accent,
      highContrast: highContrast,
      style: style,
    ).call(text, key: key);
  }
}
