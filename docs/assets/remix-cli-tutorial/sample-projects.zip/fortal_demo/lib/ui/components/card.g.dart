// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'card.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// The Fortal Card recipe: a flat panel. Elevation is reserved for floating
/// layers, never cards.
///
/// It reads top to bottom: the size and focus ring, then the variant's colors
/// for rest, hover, press and selected, then disabled.
class AcmeCard extends StatelessWidget {
  const AcmeCard({
    super.key,
    this.variant = .surface,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  });

  /// A panel fill inside a 1px gray frame.
  const AcmeCard.surface({
    super.key,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  }) : variant = AcmeCardVariant.surface;

  /// No fill or frame until hovered. It sits in a negative margin equal to its
  /// padding, so its content lines up with the content around it.
  const AcmeCard.ghost({
    super.key,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  }) : variant = AcmeCardVariant.ghost;

  final AcmeCardVariant variant;

  final AcmeCardSize size;

  final CardStyler style;

  final Widget? child;

  @override
  Widget build(BuildContext _) {
    return RemixCard(
      key: key,
      style: acmeCardStyle(variant: variant, size: size, style: style),
      child: child,
    );
  }
}
