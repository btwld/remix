// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'card.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// Flat panels. Elevation is reserved for floating layers, never cards.
class AcmeCard extends StatelessWidget {
  const AcmeCard({
    super.key,
    this.variant = .surface,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  });

  const AcmeCard.surface({
    super.key,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  }) : variant = AcmeCardVariant.surface;

  const AcmeCard.ghost({
    super.key,
    this.size = .size1,
    this.style = const CardStyler.create(),
    this.child,
  }) : variant = AcmeCardVariant.ghost;

  final AcmeCardVariant variant;

  final AcmeCardSize size;

  final CardStyler style;

  final Widget? child;

  @override
  Widget build(BuildContext _) {
    return RemixCard(
      key: key,
      style: acmeCardStyle(variant: variant, size: size, style: style),
      child: child,
    );
  }
}
