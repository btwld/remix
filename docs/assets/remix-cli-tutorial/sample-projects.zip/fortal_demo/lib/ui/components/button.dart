import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import 'base_button.dart';
import '../theme/theme.dart';

part 'button.g.dart';

/// Acme Button size presets.
enum AcmeButtonSize { size1, size2, size3, size4 }

/// Acme Button variants.
enum AcmeButtonVariant { solid, soft, surface, outline, ghost }

/// Acme-themed Button with Acme sizes, variants, and overrides.
///
/// Default icon slots use the preset's icon size, not the ambient IconTheme.
/// An explicit icon size in [style] overrides that default.
@MixWidget(target: RemixButton.new)
ButtonStyler acmeButtonStyle({
  AcmeButtonVariant variant = .solid,
  AcmeButtonSize size = .size2,
  bool highContrast = false,
  ButtonStyler style = const ButtonStyler.create(),
}) {
  final base = _acmeButtonBaseStyler(variant, _acmeBaseButtonSize(size));
  final stateStyles = acmeBaseButtonStateStyles(
    variant: _acmeBaseButtonVariant(variant),
    highContrast: highContrast,
  );

  return _applyAcmeButtonStateStyles(base, stateStyles)
      .wrap(acmeTouchTarget())
      .onDisabled(
        ButtonStyler().containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      .merge(style);
}

ButtonStyler _acmeButtonBaseStyler(
  AcmeButtonVariant variant,
  AcmeBaseButtonSize size,
) {
  final metrics = acmeBaseButtonMetrics(size);
  var style = ButtonStyler(
    icon: .size(acmeBaseButtonIconSize(size)),
    container: .direction(.horizontal).mainAxisSize(.min).spacing(metrics.gap),
    label: .style(metrics.text.mix()).fontWeight(
      variant == .ghost
          ? AcmeTokens.fontWeightRegular()
          : AcmeTokens.fontWeightMedium(),
    ),
    spinner: .size(metrics.spinnerSize)
        .opacity(0.65)
        .leafRadius(AcmeTokens.radius1())
        .duration(const Duration(milliseconds: 800)),
  ).borderRadius(.all(metrics.radius));

  if (variant == .ghost) {
    final ghost = acmeBaseButtonGhostMetrics(size);
    style = style
        .spacing(ghost.gap)
        .padding(
          .symmetric(horizontal: ghost.paddingX, vertical: ghost.paddingY),
        )
        .margin(.symmetric(horizontal: ghost.marginX, vertical: ghost.marginY));
  } else {
    style = style
        .minHeight(metrics.height)
        .padding(.horizontal(metrics.paddingX))
        .icon(.opacity(0.9));
  }
  return style;
}

AcmeBaseButtonVariant _acmeBaseButtonVariant(AcmeButtonVariant variant) =>
    switch (variant) {
      .solid => .solid,
      .soft => .soft,
      .surface => .surface,
      .outline => .outline,
      .ghost => .ghost,
    };

AcmeBaseButtonSize _acmeBaseButtonSize(AcmeButtonSize size) => switch (size) {
  .size1 => .size1,
  .size2 => .size2,
  .size3 => .size3,
  .size4 => .size4,
};

ButtonStyler _applyAcmeButtonStateStyles(
  ButtonStyler base,
  AcmeBaseButtonStateStyles stateStyles,
) {
  final pressed = _applyAcmeButtonState(
    ButtonStyler().animate(acmeBaseButtonActiveMotion),
    stateStyles.pressed,
  );

  return _applyAcmeButtonState(
        base.animate(acmeBaseButtonRestMotion),
        stateStyles.idle,
      )
      .onHovered(
        _applyAcmeButtonState(
          ButtonStyler().animate(acmeBaseButtonActiveMotion),
          stateStyles.hovered,
        ),
      )
      .onPressed(pressed)
      .onDisabled(_applyAcmeButtonState(ButtonStyler(), stateStyles.disabled))
      .onFocusVisible(
        _applyAcmeButtonState(ButtonStyler(), stateStyles.focusVisible),
      )
      .onDisabled(
        _applyAcmeButtonState(ButtonStyler(), stateStyles.disabledFocus),
      );
}

ButtonStyler _applyAcmeButtonState(
  ButtonStyler style,
  AcmeBaseButtonStateStyle state,
) {
  var result = style;
  final foreground = state.foreground;
  if (foreground != null) {
    result = result
        .label(.color(foreground))
        .icon(.color(foreground))
        .spinner(.color(foreground));
  }
  if (state.background != null) {
    result = result.color(state.background!);
  }
  if (state.effects != null) {
    result = result.containerEffects(state.effects!);
  }
  if (state.spinnerOpacity != null) {
    result = result.spinner(.opacity(state.spinnerOpacity!));
  }
  if (state.modifier != null) {
    result = result.wrap(state.modifier!);
  }
  return result;
}
