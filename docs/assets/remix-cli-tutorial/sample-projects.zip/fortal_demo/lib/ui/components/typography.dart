import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

/// The nine steps of this design system's text scale, from [AcmeTokens].
/// Pixel values are at 100% theme scaling.
enum AcmeTextSize {
  /// 12px.
  size1,

  /// 14px.
  size2,

  /// 16px. The default for body text.
  size3,

  /// 18px.
  size4,

  /// 20px.
  size5,

  /// 24px.
  size6,

  /// 28px.
  size7,

  /// 36px.
  size8,

  /// 60px.
  size9,
}

/// The font weights of the text scale.
enum AcmeTextWeight {
  /// Light, 300. For large display text.
  light,

  /// Body text.
  regular,

  /// Labels and emphasis.
  medium,

  /// Headings.
  bold,
}

/// The text style token of a [size] on the scale.
TextStyleToken acmeTextSizeToken(AcmeTextSize size) => switch (size) {
  .size1 => AcmeTokens.text1,
  .size2 => AcmeTokens.text2,
  .size3 => AcmeTokens.text3,
  .size4 => AcmeTokens.text4,
  .size5 => AcmeTokens.text5,
  .size6 => AcmeTokens.text6,
  .size7 => AcmeTokens.text7,
  .size8 => AcmeTokens.text8,
  .size9 => AcmeTokens.text9,
};

/// The font weight token of a [weight].
FontWeightToken acmeTextWeightToken(AcmeTextWeight weight) => switch (weight) {
  .light => AcmeTokens.fontWeightLight,
  .regular => AcmeTokens.fontWeightRegular,
  .medium => AcmeTokens.fontWeightMedium,
  .bold => AcmeTokens.fontWeightBold,
};

/// [truncate] deliberately wins over [softWrap], forcing one ellipsized line.
TextStyler acmeApplyTextFlow(
  TextStyler style, {
  TextAlign? align,
  required bool softWrap,
  required bool truncate,
}) {
  if (align != null) style = style.textAlign(align);
  if (truncate) {
    return style.maxLines(1).softWrap(false).overflow(TextOverflow.ellipsis);
  }

  return style.softWrap(softWrap);
}

/// [style] with the accent's text color, or accent step 12 under
/// [highContrast].
TextStyler acmeAccentForeground(
  TextStyler style, {
  required bool highContrast,
}) => style.color(
  highContrast ? AcmeTokens.accent12() : AcmeTokens.accentContentAlpha(),
);

/// The text style of [size], resolved against [context].
///
/// Code, Kbd, and Link derive em-relative geometry from the resolved font size,
/// so unlike the other recipes they cannot stay context-free.
TextStyle acmeResolveTextToken(BuildContext context, AcmeTextSize size) =>
    MixScope.tokenOf(acmeTextSizeToken(size), context);

Color acmeResolveColor(BuildContext context, ColorToken token) =>
    MixScope.tokenOf(token, context);

/// The theme's radius factor, read back from the resolved `radius1`.
///
/// Derived from the resolved `radius1` rather than duplicating this design
/// system's radius table, so theme radius and scaling changes flow through.
double acmeRadiusFactor(BuildContext context) {
  final scaling = AcmeTheme.of(context).scaling.factor;
  final radius = MixScope.tokenOf(AcmeTokens.radius1, context);

  return radius.x / (3 * scaling);
}
