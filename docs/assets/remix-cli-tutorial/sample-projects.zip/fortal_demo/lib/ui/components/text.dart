import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';
import 'typography.dart';

part 'text.g.dart';

/// Acme-themed body text on the Acme nine-step scale.
@MixWidget()
TextStyler acmeTextStyle({
  AcmeTextSize? size,
  AcmeTextWeight? weight,
  TextAlign? align,
  bool softWrap = true,
  bool truncate = false,
  bool accent = false,
  bool highContrast = false,
  TextStyler style = const TextStyler.create(),
}) {
  var recipe = TextStyler().style(
    acmeTextSizeToken(size ?? AcmeTextSize.size3).mix(),
  );
  recipe = recipe.fontWeight(
    acmeTextWeightToken(weight ?? AcmeTextWeight.regular)(),
  );
  recipe = accent
      ? acmeAccentForeground(recipe, highContrast: highContrast)
      : recipe.color(AcmeTokens.gray12());
  recipe = recipe.inherit(false);

  return acmeApplyTextFlow(
    recipe,
    align: align,
    softWrap: softWrap,
    truncate: truncate,
  ).merge(style);
}
