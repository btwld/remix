import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'card.g.dart';

enum AcmeCardVariant { surface, ghost }

enum AcmeCardSize { size1, size2, size3, size4, size5 }

/// Flat panels. Elevation is reserved for floating layers, never cards.
@MixWidget(target: RemixCard.new)
CardStyler acmeCardStyle({
  AcmeCardVariant variant = .surface,
  AcmeCardSize size = .size1,
  CardStyler style = const CardStyler.create(),
}) {
  final metrics = _acmeCardMetrics(size);
  final base = CardStyler()
      .padding(.all(metrics.padding))
      .borderRadius(.all(metrics.radius))
      .clipBehavior(.antiAlias)
      .onFocusVisible(.containerEffects(acmeFocusOutline()));

  return (switch (variant) {
        .surface =>
          base
              .color(AcmeTokens.colorPanel())
              .border(
                .all(
                  .color(AcmeTokens.gray6()).width(AcmeTokens.borderWidth1()),
                ),
              )
              .containerEffects(
                RemixBoxEffectsMix.backdropBlur(AcmeTokens.panelBlur()),
              )
              .onHovered(.border(.all(.color(AcmeTokens.gray7()))))
              .onPressed(.color(AcmeTokens.gray3()))
              .onSelected(.color(AcmeTokens.gray3())),
        .ghost =>
          base
              .margin(.all(metrics.ghostMargin))
              .color(const Color(0x00000000))
              .onHovered(.color(AcmeTokens.grayA3()))
              .onPressed(.color(AcmeTokens.grayA4()))
              .onSelected(.color(AcmeTokens.grayA3())),
      })
      .onDisabled(
        CardStyler().containerEffects(
          RemixBoxEffectsMix(outline: BorderSideMix(style: .none)),
        ),
      )
      .merge(style);
}

({double padding, double ghostMargin, Radius radius}) _acmeCardMetrics(
  AcmeCardSize size,
) => switch (size) {
  .size1 => (
    padding: AcmeTokens.space3(),
    ghostMargin: AcmeTokens.cardGhostMargin1(),
    radius: AcmeTokens.radius4(),
  ),
  .size2 => (
    padding: AcmeTokens.space4(),
    ghostMargin: AcmeTokens.cardGhostMargin2(),
    radius: AcmeTokens.radius4(),
  ),
  .size3 => (
    padding: AcmeTokens.space5(),
    ghostMargin: AcmeTokens.cardGhostMargin3(),
    radius: AcmeTokens.radius5(),
  ),
  .size4 => (
    padding: AcmeTokens.space6(),
    ghostMargin: AcmeTokens.cardGhostMargin4(),
    radius: AcmeTokens.radius5(),
  ),
  .size5 => (
    padding: AcmeTokens.space8(),
    ghostMargin: AcmeTokens.cardGhostMargin5(),
    radius: AcmeTokens.radius6(),
  ),
};
