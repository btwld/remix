import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'card.g.dart';

/// The looks a card comes in.
enum AcmeCardVariant {
  /// A panel fill inside a 1px gray frame.
  surface,

  /// No fill or frame until hovered. It sits in a negative margin equal to its
  /// padding, so its content lines up with the content around it.
  ghost,
}

/// The sizes a card comes in. Pixel values are at 100% theme scaling.
enum AcmeCardSize {
  /// 12px padding.
  size1,

  /// 16px padding.
  size2,

  /// 24px padding.
  size3,

  /// 32px padding.
  size4,

  /// 48px padding.
  size5,
}

/// The Fortal Card recipe: a flat panel. Elevation is reserved for floating
/// layers, never cards.
///
/// It reads top to bottom: the size and focus ring, then the variant's colors
/// for rest, hover, press and selected, then disabled.
@MixWidget(target: RemixCard.new)
CardStyler acmeCardStyle({
  AcmeCardVariant variant = .surface,
  AcmeCardSize size = .size1,
  CardStyler style = const CardStyler.create(),
}) => _base(size)
    .merge(switch (variant) {
      .surface => _surface(),
      .ghost => _ghost(size),
    })
    .onDisabled(.containerEffects(.outline(.style(.none))))
    .merge(style);

/// The padding, corner size and clipping of each step, and the focus ring.
CardStyler _base(AcmeCardSize size) {
  final (:padding, :radius) = switch (size) {
    .size1 => (padding: AcmeTokens.space3(), radius: AcmeTokens.radius4()),
    .size2 => (padding: AcmeTokens.space4(), radius: AcmeTokens.radius4()),
    .size3 => (padding: AcmeTokens.space5(), radius: AcmeTokens.radius5()),
    .size4 => (padding: AcmeTokens.space6(), radius: AcmeTokens.radius5()),
    .size5 => (padding: AcmeTokens.space8(), radius: AcmeTokens.radius6()),
  };

  return CardStyler()
      .padding(.all(padding))
      .borderRadius(.all(radius))
      .clipBehavior(.antiAlias)
      .onFocusVisible(.containerEffects(acmeFocusOutline()));
}

CardStyler _surface() => CardStyler()
    .color(AcmeTokens.colorPanel())
    .border(.all(.color(AcmeTokens.gray6()).width(AcmeTokens.borderWidth1())))
    .containerEffects(.backdropBlur(AcmeTokens.panelBlur()))
    .onHovered(.border(.all(.color(AcmeTokens.gray7()))))
    .onPressed(.color(AcmeTokens.gray3()))
    .onSelected(.color(AcmeTokens.gray3()));

CardStyler _ghost(AcmeCardSize size) => CardStyler()
    .margin(.all(_ghostMargin(size)))
    .color(const Color(0x00000000))
    .onHovered(.color(AcmeTokens.grayA3()))
    .onPressed(.color(AcmeTokens.grayA4()))
    .onSelected(.color(AcmeTokens.grayA3()));

/// The negative margin that cancels a ghost card's padding.
double _ghostMargin(AcmeCardSize size) => switch (size) {
  .size1 => AcmeTokens.cardGhostMargin1(),
  .size2 => AcmeTokens.cardGhostMargin2(),
  .size3 => AcmeTokens.cardGhostMargin3(),
  .size4 => AcmeTokens.cardGhostMargin4(),
  .size5 => AcmeTokens.cardGhostMargin5(),
};
