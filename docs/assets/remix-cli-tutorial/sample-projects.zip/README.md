# Remix CLI tutorial samples

The Vanilla and Fortal Launchpad samples from the Remix settings-screen tutorial.
`default_demo` holds the Vanilla project; `fortal_demo` holds the Fortal project.
Callbacks use local state and send no requests.

1. Use Flutter 3.44 or newer, which bundles Dart 3.12. Check with `flutter --version`.
2. Open `default_demo` or `fortal_demo`.
3. Run `flutter pub get`, `flutter analyze`, and `flutter test`.
4. Run `flutter run -d chrome` to open the application in a browser.

Packages resolve from pub.dev: remix 1.0.0-rc.1 and remix_ui_fonts 0.1.0.
The tutorial uses the globally activated remix_cli 1.0.0-beta.1. `remix.yaml` pins the component
registry to revision c726e8995f08db690a255754e587fc7fc5d7ba47.

`lib/main.dart` is the application. `lib/ui` holds the recipes the CLI installed and
the adapters it generated; an ordinary `remix add` preserves your edits there. The
Vanilla medium Button `minHeight` is changed from `AcmeTokens.controlMd` (36) to `44.0`.
Each `pubspec.yaml` declares `sdk: ^3.12.0`, the floor the tutorial states,
in place of the constraint `flutter create` wrote on the replay SDK.

Replayed 2026-11-10 with Flutter 3.44.0.
