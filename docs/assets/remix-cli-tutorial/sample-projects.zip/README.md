# Remix CLI tutorial samples

These are the current Vanilla and Fortal Launchpad samples, replayed October 31, 2026.
The Vanilla directory retains its original default_demo name; remix.yaml selects vanilla.
Callbacks use local state and send no requests.

1. Use Flutter 3.44.0 and Dart 3.12.0 (each sample includes an FVM pin).
2. Check out Remix at 2556203413520874c4e6d7682e8e1737f4b9f360.
3. Open default_demo or fortal_demo.
4. Replace /path/to/remix in pubspec.yaml and pubspec_overrides.yaml with the absolute checkout path.
5. Run flutter pub get, flutter analyze, flutter test, and flutter build web --release.
6. Run flutter run -d chrome to inspect the application in your browser.

The local CLI and Remix/font overrides use that checkout. The remote registry is separately
pinned to the same SHA in remix.yaml. Pub refreshes path entries in pubspec.lock.
The archive excludes package caches and build outputs. Installed source and generated
adapters came from the CLI; ordinary add preserves edits. Explicit --overwrite replaces them.

lib/main.dart owns the host, navigation, form and callbacks. lib/ui contains owned recipes.
Vanilla's medium Button minHeight is customized from AcmeTokens.controlMd (36) to 44.0.
The Fortal sample uses Mar and keeps its own size vocabulary. The four workflow tests per
app cover form/save, disabled actions, callbacks, dialogs and Sidebar. Additional appearance
tests cover theme mode resolution. Source panels in the MDX tutorial expand from this archive.

October 31 PNG overviews are actual Flutter widget-test renderer captures at 1440x1000,
with Geist and Material Icons loaded. They are not browser screenshots. Release web builds
were validated separately; browser automation was disabled in Work settings. September 7
JPG/browser/editor captures remain historical, with their original hashes and provenance.
