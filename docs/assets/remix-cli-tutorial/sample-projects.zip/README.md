# Remix CLI tutorial samples

The Vanilla and Fortal Launchpad samples from the Remix settings-screen tutorial.
`default_demo` holds the Vanilla project; `fortal_demo` holds the Fortal project.
Callbacks use local state and send no requests.

1. Use Flutter 3.44 or newer, which bundles Dart 3.12. Check with `flutter --version`.
2. Open `default_demo` or `fortal_demo`.
3. Run `flutter pub get`, `flutter analyze`, and `flutter test`.
4. Run `flutter run -d chrome` to open the application in a browser.

Packages resolve from pub.dev: remix 1.0.0-beta.16, remix_ui_fonts 0.1.0,
and the development-only remix_cli 1.0.0-beta.1. `remix.yaml` pins the component
registry to revision 890b5e1aae971b38afb1aff75ebcc3c2001fe4e0.

`lib/main.dart` is the application. `lib/ui` holds the recipes the CLI installed and
the adapters it generated; an ordinary `remix add` preserves your edits there. The
Vanilla medium Button `minHeight` is changed from `AcmeTokens.controlMd` (36) to `44.0`.
Each `pubspec.yaml` declares `sdk: ^3.12.0`, the floor the tutorial states,
in place of the constraint `flutter create` wrote on the replay SDK.

Replayed 2026-11-05 with Flutter 3.47.9.
