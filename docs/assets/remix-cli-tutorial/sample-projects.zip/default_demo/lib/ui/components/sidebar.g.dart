// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sidebar.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// The application's Sidebar recipe.
///
/// A sidebar is the navigation panel down one edge of an application shell.
/// Remix owns the rendering, the header/content/footer stacking, Tab traversal
/// across destinations, the selection semantics, and the navigation
/// landmark; this recipe owns the panel surface, the region insets, the
/// section rhythm, and the label type.
///
/// It takes no variant and no size. There is one panel per shell, and the
/// thing that actually varies between applications — how wide it is — is not
/// the recipe's to decide: the host sizes the panel, because the same panel
/// is usually presented as a drawer at narrow widths and the drawer's width
/// is a layout decision. Nothing here sets a width, and nothing here pads the
/// header, whose metrics normally have to line up with the app bar beside it:
/// give the header the `app_bar` item's toolbar height and bottom hairline.
///
/// This recipe **depends on the `toggle` and `tooltip` items**, which is why
/// its registry entry lists both beside `theme`. A destination is a toggle: it
/// is a control that stays pressed, and `SidebarSpec` takes its style as a
/// `ToggleStyler` field. Handing it the application's own ghost toggle recipe
/// is what keeps a selected destination and a selected toggle the same colour
/// without restating one component inside another. The same reasoning covers
/// the tooltip: when the host collapses the panel to an icon rail, each
/// destination's label appears in the application's own tooltip recipe.
///
/// The panel is the `sidebar` surface, a step apart from the page, with a
/// `sidebarBorder` edge. Destinations are 32px rows that sit on `sidebarAccent`
/// while hovered or current, and the current one is set at medium weight.
/// Everything shares one 8px inset, so labels, destinations, and the footer
/// line up on one left edge.
class AcmeSidebar<T extends Object> extends StatelessWidget {
  const AcmeSidebar({
    super.key,
    this.style = const SidebarStyler.create(),
    this.header,
    this.collapsed = false,
    this.showTooltips = true,
    this.tooltipPositioning,
    this.expandedWidth,
    this.collapsedWidth,
    this.animationStyle = const AnimationStyle(),
    required this.sections,
    required this.selectedValue,
    this.onSelected,
    this.footer,
    this.enabled = true,
    this.semanticLabel,
    this.excludeSemantics = false,
  });

  final SidebarStyler style;

  final Widget? header;

  final bool collapsed;

  final bool showTooltips;

  final OverlayPositionConfig? tooltipPositioning;

  final double? expandedWidth;

  final double? collapsedWidth;

  final AnimationStyle animationStyle;

  final List<RemixSidebarSection<T>> sections;

  final T? selectedValue;

  final ValueChanged<T>? onSelected;

  final Widget? footer;

  final bool enabled;

  final String? semanticLabel;

  final bool excludeSemantics;

  @override
  Widget build(BuildContext _) {
    return RemixSidebar<T>(
      key: key,
      style: acmeSidebarStyle(style: style),
      header: header,
      collapsed: collapsed,
      showTooltips: showTooltips,
      tooltipPositioning: tooltipPositioning,
      expandedWidth: expandedWidth,
      collapsedWidth: collapsedWidth,
      animationStyle: animationStyle,
      sections: sections,
      selectedValue: selectedValue,
      onSelected: onSelected,
      footer: footer,
      enabled: enabled,
      semanticLabel: semanticLabel,
      excludeSemantics: excludeSemantics,
    );
  }
}
