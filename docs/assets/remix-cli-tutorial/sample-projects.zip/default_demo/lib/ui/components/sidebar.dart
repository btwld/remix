import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/effects.dart';
import '../theme/tokens.dart';
import 'toggle.dart';
import 'tooltip.dart';

part 'sidebar.g.dart';

/// The application's Sidebar recipe.
///
/// A sidebar is the navigation panel down one edge of an application shell.
/// Remix owns the rendering, the header/content/footer stacking, Tab traversal
/// across destinations, the selection semantics, and the navigation
/// landmark; this recipe owns the panel surface, the region insets, the
/// section rhythm, and the label type.
///
/// It takes no variant and no size. There is one panel per shell, and the
/// thing that actually varies between applications — how wide it is — is not
/// the recipe's to decide: the host sizes the panel, because the same panel
/// is usually presented as a drawer at narrow widths and the drawer's width
/// is a layout decision. Nothing here sets a width, and nothing here pads the
/// header, whose metrics normally have to line up with the app bar beside it:
/// give the header the `app_bar` item's toolbar height and bottom hairline.
///
/// This recipe **depends on the `toggle` and `tooltip` items**, which is why
/// its registry entry lists both beside `theme`. A destination is a toggle: it
/// is a control that stays pressed, and `SidebarSpec` takes its style as a
/// `ToggleStyler` field. Handing it the application's own ghost toggle recipe
/// is what keeps a selected destination and a selected toggle the same colour
/// without restating one component inside another. The same reasoning covers
/// the tooltip: when the host collapses the panel to an icon rail, each
/// destination's label appears in the application's own tooltip recipe.
///
/// The panel is the `sidebar` surface, a step apart from the page, with a
/// `sidebarBorder` edge. Destinations are 32px rows that sit on `sidebarAccent`
/// while hovered or current, and the current one is set at medium weight.
/// Everything shares one 8px inset, so labels, destinations, and the footer
/// line up on one left edge.
@MixWidget(target: RemixSidebar.new)
SidebarStyler acmeSidebarStyle({
  SidebarStyler style = const SidebarStyler.create(),
}) => SidebarStyler(
  container: FlexBoxStyler()
      .color(AcmeTokens.sidebar())
      .border(
        .end(
          .color(AcmeTokens.sidebarBorder()).width(AcmeTokens.strokeHairline),
        ),
      ),
  content: FlexBoxStyler().padding(.all(AcmeTokens.s2)).spacing(AcmeTokens.s4),
  footer: BoxStyler()
      .border(
        .top(
          .color(AcmeTokens.sidebarBorder()).width(AcmeTokens.strokeHairline),
        ),
      )
      .padding(.all(AcmeTokens.s2)),
  // A section label is a 32px row of `textXs` at medium weight in
  // `sidebarForeground` at 70%, inset like the destinations below it. It is the
  // quietest text in the panel, so it reads as a heading for the destinations
  // rather than as one of them.
  sectionLabel: TextStyler()
      .style(AcmeTokens.textXs.mix())
      .fontWeight(FontWeight.w500)
      .color(_labelColor())
      .wrap(
        .padding(
          .symmetric(horizontal: AcmeTokens.s2, vertical: AcmeTokens.s2),
        ),
      ),
  destinations: FlexBoxStyler().spacing(AcmeTokens.s1),
  destination: _destinationStyle(),
  // A collapsed rail shows each destination's label in the application's own
  // tooltip, so it reads like every other tooltip in the app.
  tooltip: acmeTooltipStyle(),
).merge(style);

/// The section label's color: `sidebarForeground` at 70%, which clears 4.5:1
/// on the `sidebar` surface in both themes.
final _labelColor = acmeTint(AcmeTokens.sidebarForeground, _labelAlpha);

/// See [_labelColor].
const _labelAlpha = 0.7;

/// One destination: the application's own ghost toggle, retuned as a navigation
/// row.
///
/// A 32px row, 8px in from the sides and 6px from the top and bottom so the
/// 20px `textSm` line fills it, with an 8px gap, set in `textSm`
/// at regular weight in `sidebarForeground`. Hovered and current rows sit on
/// `sidebarAccent`; the current one is also set at medium weight, which is
/// what tells it from a hovered row in the shipped themes, where the two
/// share a surface.
ToggleStyler _destinationStyle() {
  final highlighted = ToggleStyler()
      .color(AcmeTokens.sidebarAccent())
      .label(.color(AcmeTokens.sidebarAccentForeground()))
      .icon(.color(AcmeTokens.sidebarAccentForeground()));

  final resolved = acmeToggleStyle(variant: .ghost, size: .small)
      .container(.mainAxisSize(.max).mainAxisAlignment(.start))
      .minHeight(AcmeTokens.controlSm)
      // The reference is `h-8 p-2`: CSS fixes the height and lets the line
      // overrun the padding. Flutter lays the line out inside the padding, so
      // 6px vertically is what keeps the row at 32.
      .padding(.symmetric(horizontal: AcmeTokens.s2, vertical: AcmeTokens.s1_5))
      .spacing(AcmeTokens.s2)
      .label(.fontWeight(FontWeight.w400).color(AcmeTokens.sidebarForeground()))
      .icon(.color(AcmeTokens.sidebarForeground()))
      .onHovered(highlighted)
      .onSelected(highlighted.label(.fontWeight(FontWeight.w500)));

  return ToggleStyler.create(
    container: resolved.$container,
    label: resolved.$label,
    icon: resolved.$icon,
    variants: resolved.$variants,
    modifier: resolved.$modifier,
  );
}
