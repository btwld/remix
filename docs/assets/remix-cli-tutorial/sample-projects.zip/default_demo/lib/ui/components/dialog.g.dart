// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dialog.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// The application's Dialog recipe.
///
/// Remix owns the rendering, the modal barrier, focus trapping, the escape
/// and barrier dismissal rules, and the dialog accessibility semantics; this
/// recipe supplies the panel, the two text roles, and the action row.
///
/// It is the page's `background` fill with a `border` hairline, `radiusLg`
/// corners, the heaviest shadow in the scale, and a 24px inset. The panel is
/// centered in the viewport with 16px to spare on every side, and fills the
/// width up to 512px. The title is `textLg` semibold and set tight, the description `textSm`
/// in `mutedForeground` 8px below it, and the decisions sit at the trailing
/// edge 16px below that.
class AcmeDialog extends StatelessWidget {
  const AcmeDialog({
    super.key,
    this.style = const DialogStyler.create(),
    this.child,
    this.title,
    this.description,
    this.actions,
    this.scrollable = false,
    this.modal = true,
    this.semanticLabel,
  });

  final DialogStyler style;

  final Widget? child;

  final String? title;

  final String? description;

  final List<Widget>? actions;

  final bool scrollable;

  final bool modal;

  final String? semanticLabel;

  @override
  Widget build(BuildContext _) {
    return RemixDialog(
      key: key,
      style: acmeDialogStyle(style: style),
      child: child,
      title: title,
      description: description,
      actions: actions,
      scrollable: scrollable,
      modal: modal,
      semanticLabel: semanticLabel,
    );
  }
}
