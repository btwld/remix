import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/effects.dart';
import '../theme/tokens.dart';

part 'dialog.g.dart';

/// The application's Dialog recipe.
///
/// Remix owns the rendering, the modal barrier, focus trapping, the escape
/// and barrier dismissal rules, and the dialog accessibility semantics; this
/// recipe supplies the panel, the two text roles, and the action row.
///
/// It is the page's `background` fill with a `border` hairline, `radiusLg`
/// corners, the heaviest shadow in the scale, and a 24px inset. The panel is
/// centered in the viewport with 16px to spare on every side, and fills the
/// width up to 512px. The title is `textLg` semibold and set tight, the description `textSm`
/// in `mutedForeground` 8px below it, and the decisions sit at the trailing
/// edge 16px below that.
@MixWidget(target: RemixDialog.new)
DialogStyler acmeDialogStyle({
  DialogStyler style = const DialogStyler.create(),
}) => DialogStyler()
    // A dialog route hands its page the whole viewport; without the wrap the
    // panel would take all of it. The padding leaves room at the edges, and
    // the alignment lets the panel keep its own size.
    .wrap(
      .padding(.all(AcmeTokens.s4)).align(alignment: .center).orderOfModifiers([
        PaddingModifier,
        AlignModifier,
      ]),
    )
    .color(AcmeTokens.background())
    .border(.color(AcmeTokens.border()).width(AcmeTokens.strokeHairline))
    .borderRadius(.all(AcmeTokens.radiusLg()))
    .padding(.all(AcmeTokens.s6))
    .width(AcmeTokens.dialogMaxWidth)
    .shadows(AcmeShadow.lg.box)
    .title(
      .style(AcmeTokens.textLg.mix())
          // A line height of 1: the title sits on its own size, so the gap
          // below it is the 8px the recipe says rather than 8 plus the line
          // box's leading.
          .height(1)
          .fontWeight(FontWeight.w600)
          .color(AcmeTokens.foreground())
          .wrap(.padding(.bottom(AcmeTokens.s2))),
    )
    .description(
      .style(AcmeTokens.textSm.mix()).color(AcmeTokens.mutedForeground()),
    )
    // The actions sit at the trailing edge, which is where a reader looks for
    // the decision once they have read the description.
    .actions(
      FlexBoxStyler()
          .direction(.horizontal)
          .mainAxisAlignment(.end)
          .spacing(AcmeTokens.s2)
          .margin(.top(AcmeTokens.s4)),
    )
    .merge(style);
